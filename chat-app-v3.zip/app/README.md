# السيرفر
1. docker compose up -d
2. cd server && cp .env.example .env
3. npm install && npm run dev      (كود الـ OTP بيظهر في الكونسول)

# تطبيق Flutter
1. flutter create chat_app
2. استبدل مجلد lib/ وملف pubspec.yaml بالموجودين في mobile/
3. أندرويد: ضيف في android/app/src/main/AndroidManifest.xml جوه <application ...>:
   android:usesCleartextTraffic="true"     (للتجربة المحلية فقط)
4. عدّل lib/core/config.dart لو بتجرب على جهاز حقيقي
5. flutter pub get && flutter run

# التجربة
سجّل بحسابين (محاكيين أو جهاز + محاكي) وابدأ محادثة من زر القلم بإدخال رقم الطرف التاني.

# الصور والملفات المشفرة
- قاعدة بيانات موجودة: شغّل server/migrations/003_media.sql
- السيرفر: ضيف MEDIA_DIR في .env (مفيش مكتبات جديدة)
- Flutter: flutter pub get
- iOS: ضيف في ios/Runner/Info.plist المفاتيح NSPhotoLibraryUsageDescription و NSCameraUsageDescription
- الحدود: 10 ميجا للملف، 500 ميجا لكل مستخدم

# الستوريز
- قاعدة بيانات موجودة: شغّل server/migrations/004_stories.sql
- مفيش مكتبات جديدة (نفس مكتبات الصور)

# الحالة على طريقة واتساب
- قاعدة بيانات موجودة: شغّل server/migrations/005_status_whatsapp.sql
- مفيش مكتبات جديدة

# الجروبات + Snaps + الملف الشخصي (النسخة 006)
- قاعدة بيانات موجودة: شغّل server/migrations/006_groups_snaps.sql (آمنة لو اتشغلت أكتر من مرة)
- قاعدة بيانات جديدة: schema.sql فيه كل حاجة
- مفيش مكتبات جديدة في السيرفر ولا في Flutter
- الجديد: مجموعات (حد أقصى 100 عضو، المشرف يضيف/يشيل)، آخر رسالة وعدّاد غير المقروء، "بيكتب..." ومتصل/آخر ظهور،
  علامة "وصلت" و"اتقرأت" (في الجروب لما الكل يقرا)، مسح عندي/للجميع، Snaps بتتفتح مرة واحدة، 🔥 Streaks، ملفي الشخصي

# الإشعارات والرسائل الصوتية
- Flutter: `flutter pub get`
- الصوت — أندرويد: ضيف `<uses-permission android:name="android.permission.RECORD_AUDIO"/>` في AndroidManifest.xml. iOS: مفتاح NSMicrophoneUsageDescription في Info.plist
- الإشعارات (اختياري، التطبيق بيشتغل من غيرها):
  1. أنشئ مشروع Firebase وضيف التطبيق، وحط google-services.json في android/app (و GoogleService-Info.plist لـ iOS) وفعّل plugin الـ google-services
  2. من Firebase: Project settings → Service accounts → Generate key، واكتب مساره في server/.env في FCM_SERVICE_ACCOUNT
  3. الإشعار بيوصل "رسالة جديدة" بس، من غير اسم ولا محتوى
