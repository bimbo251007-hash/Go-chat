ALTER TABLE stories ALTER COLUMN media_url DROP NOT NULL;
ALTER TABLE stories ADD COLUMN IF NOT EXISTS media_id UUID REFERENCES media(id) ON DELETE SET NULL;
ALTER TABLE stories ADD COLUMN IF NOT EXISTS ciphertext TEXT;
ALTER TABLE stories ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE story_views ADD COLUMN IF NOT EXISTS viewed_at TIMESTAMPTZ NOT NULL DEFAULT now();
CREATE TABLE IF NOT EXISTS story_audience (
  story_id UUID REFERENCES stories(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (story_id, user_id)
);
CREATE INDEX IF NOT EXISTS stories_user_idx ON stories (user_id, expires_at);
CREATE INDEX IF NOT EXISTS story_audience_user_idx ON story_audience (user_id);
