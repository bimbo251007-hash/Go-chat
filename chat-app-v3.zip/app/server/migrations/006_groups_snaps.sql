-- الجروبات
ALTER TABLE conversations ADD COLUMN IF NOT EXISTS name TEXT;
ALTER TABLE conversations ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES users(id) ON DELETE SET NULL;
-- joined_at: الرسايل اللي قبل انضمام العضو مش بتظهر له (مش متشفرة ليه). الأعضاء القدام = وقت إنشاء المحادثة.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='members' AND column_name='joined_at') THEN
    ALTER TABLE members ADD COLUMN joined_at TIMESTAMPTZ NOT NULL DEFAULT now();
    UPDATE members m SET joined_at = c.created_at FROM conversations c WHERE c.id = m.conversation_id;
  END IF;
END $$;
-- آخر وقت قرا فيه العضو المحادثة (لعدّاد غير المقروء وعلامة "اتقرأت" في الجروبات)
ALTER TABLE members ADD COLUMN IF NOT EXISTS last_read_at TIMESTAMPTZ NOT NULL DEFAULT now();

-- مسح الرسائل
ALTER TABLE messages ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
CREATE TABLE IF NOT EXISTS message_hidden (            -- "مسح عندي بس"
  message_id UUID REFERENCES messages(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (message_id, user_id)
);
CREATE INDEX IF NOT EXISTS messages_conv_created_idx ON messages (conversation_id, created_at DESC);

-- الملف الشخصي والتواجد
ALTER TABLE users ADD COLUMN IF NOT EXISTS about TEXT NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS hide_last_seen BOOLEAN NOT NULL DEFAULT false;

-- أجهزة الإشعارات (FCM/APNs)
CREATE TABLE IF NOT EXISTS devices (
  token TEXT PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('android','ios')),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS devices_user_idx ON devices (user_id);

-- Snaps: عرض مرة واحدة
CREATE TABLE IF NOT EXISTS message_views (
  message_id UUID REFERENCES messages(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  viewed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

-- Streaks: أيام متتالية تبادل فيها الاتنين Snaps
CREATE TABLE IF NOT EXISTS snap_days (
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
  day DATE NOT NULL,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (conversation_id, day, user_id)
);
CREATE TABLE IF NOT EXISTS streaks (
  conversation_id UUID PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
  count INT NOT NULL DEFAULT 0,
  last_day DATE
);
