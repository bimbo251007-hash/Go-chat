ALTER TABLE stories ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'image' CHECK (kind IN ('image','text'));
CREATE TABLE IF NOT EXISTS status_privacy (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  mode TEXT NOT NULL DEFAULT 'contacts' CHECK (mode IN ('contacts','except','only')),
  user_ids UUID[] NOT NULL DEFAULT '{}'
);
