import express, { Router } from "express";
import rateLimit from "express-rate-limit";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { z } from "zod";
import { pool } from "./db.js";
import { requireAuth, AuthedRequest } from "./auth.js";
import { sendTo } from "./chat.js";

// السيرفر بيخزن Blobs مشفرة بس. مفتاح فك التشفير بيسافر جوه الرسالة المشفرة E2E،
// فمفيش طريقة يشوف بيها محتوى الصور أو الملفات.
export const MEDIA_DIR = path.resolve(process.env.MEDIA_DIR ?? "uploads");
fs.mkdirSync(MEDIA_DIR, { recursive: true, mode: 0o700 });

const MAX_SIZE = 12 * 1024 * 1024;       // 12MB للملف الواحد
const USER_QUOTA = 500 * 1024 * 1024;    // 500MB لكل مستخدم

const uploadLimiter = rateLimit({
  windowMs: 60 * 60_000, limit: 60, standardHeaders: true, legacyHeaders: false,
  keyGenerator: (req) => "up:" + (req as AuthedRequest).userId,
  message: { error: "رفع كتير، حاول بعد شوية" },
});

export const mediaRouter = Router();
mediaRouter.use(requireAuth); // التحقق قبل قراءة أي جسم للطلب

mediaRouter.post(
  "/",
  uploadLimiter,
  express.raw({ type: "application/octet-stream", limit: MAX_SIZE }),
  async (req: AuthedRequest, res) => {
    const buf = req.body;
    if (!Buffer.isBuffer(buf) || buf.length <= 28 || buf.length > MAX_SIZE)
      return res.status(400).json({ error: "ملف غير صالح" });

    const used = await pool.query(
      "SELECT COALESCE(SUM(size),0)::bigint AS used FROM media WHERE owner_id=$1", [req.userId]);
    if (Number(used.rows[0].used) + buf.length > USER_QUOTA)
      return res.status(413).json({ error: "المساحة المسموحة خلصت" });

    const id = crypto.randomUUID();
    const file = path.join(MEDIA_DIR, id);
    await fs.promises.writeFile(file, buf, { flag: "wx", mode: 0o600 });
    try {
      await pool.query("INSERT INTO media (id, owner_id, size) VALUES ($1,$2,$3)",
        [id, req.userId, buf.length]);
    } catch (e) {
      await fs.promises.unlink(file).catch(() => {});
      throw e;
    }
    res.json({ id });
  }
);

// التحميل: صاحب الملف أو عضو في محادثة فيها رسالة بتشاور عليه.
// Snap: التحميل نفسه هو "الفتح". المستلم يقدر ينزّله مرة واحدة (مع نافذة 60 ثانية لإعادة المحاولة لو النت قطع).
const SNAP_RETRY_SEC = 60;
mediaRouter.get("/:id", async (req: AuthedRequest, res) => {
  const id = z.string().uuid().safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  const me = req.userId!;

  const { rows } = await pool.query(
    `SELECT m.id, m.owner_id,
       EXISTS (SELECT 1 FROM messages g JOIN members mm ON mm.conversation_id=g.conversation_id
               WHERE g.media_id=m.id AND g.type<>'snap' AND g.deleted_at IS NULL AND mm.user_id=$2) AS regular,
       EXISTS (SELECT 1 FROM stories s JOIN story_audience a ON a.story_id=s.id
               WHERE s.media_id=m.id AND a.user_id=$2 AND s.expires_at > now()) AS story
     FROM media m WHERE m.id=$1`, [id.data, me]);
  const row = rows[0];
  let allowed = !!row && (row.owner_id === me || row.regular || row.story);

  if (row && !allowed) {
    // Snap: مستلم (مش المرسل)، مفتحتهوش قبل كده (أو لسه في نافذة إعادة المحاولة)، ولسه مانتهتش
    const snap = await pool.query(
      `SELECT g.id, g.sender_id FROM messages g JOIN members mm ON mm.conversation_id=g.conversation_id
       WHERE g.media_id=$1 AND g.type='snap' AND g.deleted_at IS NULL AND g.sender_id<>$2 AND mm.user_id=$2
         AND (g.expires_at IS NULL OR g.expires_at > now())`, [id.data, me]);
    const g = snap.rows[0];
    if (g) {
      const first = await pool.query(
        "INSERT INTO message_views (message_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING message_id",
        [g.id, me]);
      if (first.rowCount) {
        sendTo(g.sender_id, { type: "snap_opened", messageId: g.id, userId: me });
        allowed = true;
      } else {
        allowed = !!(await pool.query(
          `SELECT 1 FROM message_views WHERE message_id=$1 AND user_id=$2
             AND viewed_at > now() - ($3::int * interval '1 second')`, [g.id, me, SNAP_RETRY_SEC])).rowCount;
      }
    }
  }
  if (!allowed) return res.status(404).json({ error: "not found" });
  res.set({
    "Content-Type": "application/octet-stream",
    "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.sendFile(path.join(MEDIA_DIR, id.data));
});

// Snaps اللي كل المستلمين فتحوها (وعدّى وقت إعادة التحميل): نمسح الملف نهائيًا من الداتابيز والقرص
export async function purgeViewedSnaps() {
  const { rows } = await pool.query(
    `SELECT g.media_id FROM messages g
     WHERE g.type='snap' AND g.media_id IS NOT NULL
       AND EXISTS (SELECT 1 FROM members m WHERE m.conversation_id=g.conversation_id AND m.user_id<>g.sender_id)
       AND NOT EXISTS (
         SELECT 1 FROM members m WHERE m.conversation_id=g.conversation_id AND m.user_id<>g.sender_id
           AND NOT EXISTS (SELECT 1 FROM message_views v WHERE v.message_id=g.id AND v.user_id=m.user_id
                           AND v.viewed_at < now() - interval '60 seconds'))`);
  if (!rows.length) return;
  const del = await pool.query("DELETE FROM media WHERE id = ANY($1::uuid[]) RETURNING id", [rows.map((r) => r.media_id)]);
  for (const r of del.rows) await fs.promises.unlink(path.join(MEDIA_DIR, r.id)).catch(() => {});
}
