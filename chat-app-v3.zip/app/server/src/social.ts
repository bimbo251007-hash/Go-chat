import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { pool } from "./db.js";
import { requireAuth, AuthedRequest } from "./auth.js";
import { sendTo, isOnline, memberIds, notifyMembers } from "./chat.js";

const uuid = z.string().uuid();
export const socialRouter = Router();
socialRouter.use(requireAuth);

const rl = (prefix: string, windowMs: number, limit: number) =>
  rateLimit({
    windowMs, limit, standardHeaders: true, legacyHeaders: false,
    keyGenerator: (req) => `${prefix}:` + (req as AuthedRequest).userId,
    message: { error: "طلبات كتير، حاول بعدين" },
  });
const groupLimiter = rl("g", 3600_000, 30);

const MAX_GROUP = 100;

// جهات الاتصال = اللي بينك وبينهم محادثة فردية (نفس تعريف الستوريز)
const myContactIds = async (me: string): Promise<Set<string>> => {
  const { rows } = await pool.query(
    `SELECT DISTINCT b.user_id FROM members a
     JOIN conversations c ON c.id=a.conversation_id AND c.type='direct'
     JOIN members b ON b.conversation_id=a.conversation_id AND b.user_id<>a.user_id
     WHERE a.user_id=$1`, [me]);
  return new Set(rows.map((r) => r.user_id));
};

const roleOf = async (convId: string, userId: string) =>
  (await pool.query(
    `SELECT m.role, c.type FROM members m JOIN conversations c ON c.id=m.conversation_id
     WHERE m.conversation_id=$1 AND m.user_id=$2`, [convId, userId])).rows[0] as
    { role: string; type: string } | undefined;

const changed = (convId: string) =>
  notifyMembers(convId, { type: "conversation_updated", conversationId: convId });

// ---------- الجروبات ----------
socialRouter.post("/conversations/group", groupLimiter, async (req: AuthedRequest, res) => {
  const p = z.object({
    name: z.string().trim().min(1).max(60),
    memberIds: z.array(uuid).min(1).max(MAX_GROUP - 1),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const me = req.userId!;
  const ids = [...new Set(p.data.memberIds)].filter((id) => id !== me);
  if (!ids.length) return res.status(400).json({ error: "اختار عضو واحد على الأقل" });
  const contacts = await myContactIds(me);
  if (!ids.every((id) => contacts.has(id)))
    return res.status(400).json({ error: "تقدر تضيف بس الناس اللي بينك وبينهم محادثة" });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const c = await client.query(
      "INSERT INTO conversations (type, name, created_by) VALUES ('group',$1,$2) RETURNING id",
      [p.data.name, me]);
    await client.query("INSERT INTO members (conversation_id, user_id, role) VALUES ($1,$2,'admin')", [c.rows[0].id, me]);
    await client.query(
      "INSERT INTO members (conversation_id, user_id) SELECT $1, unnest($2::uuid[])", [c.rows[0].id, ids]);
    await client.query("COMMIT");
    ids.forEach((id) => sendTo(id, { type: "conversation_updated", conversationId: c.rows[0].id }));
    res.json({ id: c.rows[0].id });
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
});

// أعضاء المحادثة + مفاتيحهم (التطبيق بيستخدمها لتشفير الرسالة لكل عضو)
socialRouter.get("/conversations/:id/members", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  if (!(await roleOf(id.data, req.userId!))) return res.status(403).json({ error: "forbidden" });
  const { rows } = await pool.query(
    `SELECT u.id, u.name, u.phone, u.public_key AS "publicKey", m.role
     FROM members m JOIN users u ON u.id=m.user_id
     WHERE m.conversation_id=$1 ORDER BY m.joined_at`, [id.data]);
  res.json(rows);
});

socialRouter.patch("/conversations/:id", groupLimiter, async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  const p = z.object({ name: z.string().trim().min(1).max(60) }).safeParse(req.body);
  if (!id.success || !p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const r = await roleOf(id.data, req.userId!);
  if (!r || r.type !== "group") return res.status(403).json({ error: "forbidden" });
  if (r.role !== "admin") return res.status(403).json({ error: "للمشرفين فقط" });
  await pool.query("UPDATE conversations SET name=$1 WHERE id=$2", [p.data.name, id.data]);
  await changed(id.data);
  res.json({ ok: true });
});

socialRouter.post("/conversations/:id/members", groupLimiter, async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  const p = z.object({ userIds: z.array(uuid).min(1).max(MAX_GROUP) }).safeParse(req.body);
  if (!id.success || !p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const me = req.userId!;
  const r = await roleOf(id.data, me);
  if (!r || r.type !== "group") return res.status(403).json({ error: "forbidden" });
  if (r.role !== "admin") return res.status(403).json({ error: "للمشرفين فقط" });

  const current = new Set(await memberIds(id.data));
  const contacts = await myContactIds(me);
  const add = [...new Set(p.data.userIds)].filter((u) => !current.has(u));
  if (!add.every((u) => contacts.has(u)))
    return res.status(400).json({ error: "تقدر تضيف بس الناس اللي بينك وبينهم محادثة" });
  if (current.size + add.length > MAX_GROUP) return res.status(400).json({ error: "الجروب وصل للحد الأقصى" });
  if (add.length)
    await pool.query("INSERT INTO members (conversation_id, user_id) SELECT $1, unnest($2::uuid[]) ON CONFLICT DO NOTHING",
      [id.data, add]);
  add.forEach((u) => sendTo(u, { type: "conversation_updated", conversationId: id.data }));
  await changed(id.data);
  res.json({ ok: true, added: add.length });
});

// المشرف يشيل عضو، أو العضو يغادر بنفسه
socialRouter.delete("/conversations/:id/members/:userId", groupLimiter, async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id), target = uuid.safeParse(req.params.userId);
  if (!id.success || !target.success) return res.status(400).json({ error: "bad id" });
  const me = req.userId!;
  const r = await roleOf(id.data, me);
  if (!r || r.type !== "group") return res.status(403).json({ error: "forbidden" });
  if (target.data !== me && r.role !== "admin") return res.status(403).json({ error: "للمشرفين فقط" });

  const before = await memberIds(id.data);
  if (!before.includes(target.data)) return res.status(404).json({ error: "not found" });
  await pool.query("DELETE FROM members WHERE conversation_id=$1 AND user_id=$2", [id.data, target.data]);

  const left = before.filter((u) => u !== target.data);
  if (!left.length) {
    await pool.query("DELETE FROM conversations WHERE id=$1", [id.data]); // آخر واحد مشي
  } else {
    // لو مفيش مشرف، أقدم عضو يبقى مشرف
    await pool.query(
      `UPDATE members SET role='admin' WHERE conversation_id=$1 AND user_id=(
         SELECT user_id FROM members WHERE conversation_id=$1 ORDER BY joined_at LIMIT 1)
       AND NOT EXISTS (SELECT 1 FROM members WHERE conversation_id=$1 AND role='admin')`, [id.data]);
    left.forEach((u) => sendTo(u, { type: "conversation_updated", conversationId: id.data }));
  }
  sendTo(target.data, { type: "conversation_updated", conversationId: id.data });
  res.json({ ok: true });
});

socialRouter.put("/conversations/:id/members/:userId/role", groupLimiter, async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id), target = uuid.safeParse(req.params.userId);
  const p = z.object({ role: z.enum(["admin", "member"]) }).safeParse(req.body);
  if (!id.success || !target.success || !p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const r = await roleOf(id.data, req.userId!);
  if (!r || r.type !== "group" || r.role !== "admin") return res.status(403).json({ error: "للمشرفين فقط" });
  const u = await pool.query("UPDATE members SET role=$3 WHERE conversation_id=$1 AND user_id=$2 RETURNING user_id",
    [id.data, target.data, p.data.role]);
  if (!u.rowCount) return res.status(404).json({ error: "not found" });
  // ما ينفعش الجروب يفضل من غير مشرف
  if (!(await pool.query("SELECT 1 FROM members WHERE conversation_id=$1 AND role='admin'", [id.data])).rowCount)
    await pool.query("UPDATE members SET role='admin' WHERE conversation_id=$1 AND user_id=$2", [id.data, req.userId]);
  await changed(id.data);
  res.json({ ok: true });
});

// ---------- مسح الرسائل ----------
// scope=everyone: المرسل بس (بيفضل مكانها علامة "اتمسحت")، scope=me: مسح عند المستخدم بس
socialRouter.delete("/messages/:id", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  const scope = z.enum(["me", "everyone"]).default("everyone").safeParse(req.query.scope);
  if (!id.success || !scope.success) return res.status(400).json({ error: "bad request" });
  const me = req.userId!;
  const g = await pool.query(
    `SELECT g.conversation_id, g.sender_id FROM messages g
     JOIN members m ON m.conversation_id=g.conversation_id AND m.user_id=$2 WHERE g.id=$1`, [id.data, me]);
  if (!g.rows[0]) return res.status(404).json({ error: "not found" });

  if (scope.data === "me") {
    await pool.query("INSERT INTO message_hidden (message_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING", [id.data, me]);
    return res.json({ ok: true });
  }
  if (g.rows[0].sender_id !== me) return res.status(403).json({ error: "تقدر تمسح رسايلك بس" });
  await pool.query("UPDATE messages SET deleted_at=now(), ciphertext='{}', media_id=NULL WHERE id=$1", [id.data]);
  await notifyMembers(g.rows[0].conversation_id,
    { type: "deleted", messageId: id.data, conversationId: g.rows[0].conversation_id }, me);
  res.json({ ok: true });
});

// ---------- الملف الشخصي والتواجد ----------
socialRouter.get("/me", async (req: AuthedRequest, res) => {
  const { rows } = await pool.query(
    "SELECT id, phone, name, about, avatar, hide_last_seen AS \"hideLastSeen\" FROM users WHERE id=$1", [req.userId]);
  res.json(rows[0]);
});

socialRouter.put("/me", rl("me", 60_000, 20), async (req: AuthedRequest, res) => {
  const p = z.object({
    name: z.string().trim().min(1).max(50).optional(),
    about: z.string().trim().max(140).optional(),
    hideLastSeen: z.boolean().optional(),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const { rows } = await pool.query(
    `UPDATE users SET name=COALESCE($2,name), about=COALESCE($3,about), hide_last_seen=COALESCE($4,hide_last_seen)
     WHERE id=$1 RETURNING id, phone, name, about, avatar, hide_last_seen AS "hideLastSeen"`,
    [req.userId, p.data.name ?? null, p.data.about ?? null, p.data.hideLastSeen ?? null]);
  res.json(rows[0]);
});

// حالة تواجد شخص: متاحة بس لمن يشاركه محادثة. اللي مخفي آخر ظهور بيظهر أونلاين بس.
socialRouter.get("/users/:id/presence", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  const { rows } = await pool.query(
    `SELECT u.about, u.hide_last_seen, u.last_seen_at FROM users u
     WHERE u.id=$1 AND EXISTS (
       SELECT 1 FROM members a JOIN members b ON a.conversation_id=b.conversation_id
       WHERE a.user_id=$1 AND b.user_id=$2)`, [id.data, req.userId]);
  if (!rows[0]) return res.status(404).json({ error: "not found" });
  res.json({ online: isOnline(id.data), lastSeen: rows[0].hide_last_seen ? null : rows[0].last_seen_at, about: rows[0].about });
});

// ---------- أجهزة الإشعارات ----------
socialRouter.put("/devices", rl("dev", 3600_000, 30), async (req: AuthedRequest, res) => {
  const p = z.object({ token: z.string().min(10).max(4096), platform: z.enum(["android", "ios"]) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  await pool.query(
    `INSERT INTO devices (token, user_id, platform) VALUES ($1,$2,$3)
     ON CONFLICT (token) DO UPDATE SET user_id=$2, platform=$3, updated_at=now()`,
    [p.data.token, req.userId, p.data.platform]);
  res.json({ ok: true });
});

socialRouter.delete("/devices", rl("dev", 3600_000, 30), async (req: AuthedRequest, res) => {
  const p = z.object({ token: z.string().min(10).max(4096) }).safeParse(req.body);
  if (p.success) await pool.query("DELETE FROM devices WHERE token=$1 AND user_id=$2", [p.data.token, req.userId]);
  res.json({ ok: true });
});
