import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { pool } from "./db.js";
import { requireAuth, AuthedRequest } from "./auth.js";
import { validPayload } from "./chat.js";

const uuid = z.string().uuid();
export const storiesRouter = Router();
storiesRouter.use(requireAuth);

const rl = (prefix: string, windowMs: number, limit: number, error: string) =>
  rateLimit({
    windowMs, limit, standardHeaders: true, legacyHeaders: false,
    keyGenerator: (req) => `${prefix}:` + (req as AuthedRequest).userId,
    message: { error },
  });
const postLimiter = rl("st", 24 * 3600_000, 30, "وصلت للحد اليومي للحالات");
const settingsLimiter = rl("sp", 60_000, 20, "طلبات كتير");

type Contact = { id: string; name: string; phone: string; public_key: string };

// جهات الاتصال = اللي بيني وبينهم محادثة فردية ولهم مفتاح تشفير
const contacts = async (me: string): Promise<Contact[]> =>
  (await pool.query(
    `SELECT DISTINCT u.id, u.name, u.phone, u.public_key
     FROM members a
     JOIN conversations c ON c.id=a.conversation_id AND c.type='direct'
     JOIN members b ON b.conversation_id=a.conversation_id AND b.user_id<>a.user_id
     JOIN users u ON u.id=b.user_id
     WHERE a.user_id=$1 AND u.public_key IS NOT NULL`, [me])).rows;

type Mode = "contacts" | "except" | "only";
const getPrivacy = async (me: string): Promise<{ mode: Mode; userIds: string[] }> => {
  const { rows } = await pool.query("SELECT mode, user_ids FROM status_privacy WHERE user_id=$1", [me]);
  return { mode: (rows[0]?.mode ?? "contacts") as Mode, userIds: rows[0]?.user_ids ?? [] };
};

// الجمهور المسموح حسب إعدادات الخصوصية (زي واتساب)
const allowed = async (me: string): Promise<Contact[]> => {
  const [all, pr] = await Promise.all([contacts(me), getPrivacy(me)]);
  const set = new Set(pr.userIds);
  return all.filter((c) => pr.mode === "contacts" || (pr.mode === "except" ? !set.has(c.id) : set.has(c.id)));
};

// ---------- الخصوصية ----------
storiesRouter.get("/contacts", async (req: AuthedRequest, res) => {
  const rows = await contacts(req.userId!);
  res.json(rows.map((c) => ({ id: c.id, name: c.name, phone: c.phone })));
});

storiesRouter.get("/privacy", async (req: AuthedRequest, res) => res.json(await getPrivacy(req.userId!)));

storiesRouter.put("/privacy", settingsLimiter, async (req: AuthedRequest, res) => {
  const p = z.object({
    mode: z.enum(["contacts", "except", "only"]),
    userIds: z.array(uuid).max(500).default([]),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const valid = new Set((await contacts(req.userId!)).map((c) => c.id));
  const ids = [...new Set(p.data.userIds)].filter((id) => valid.has(id));
  if (p.data.mode === "only" && ids.length === 0)
    return res.status(400).json({ error: "اختار شخص واحد على الأقل" });
  await pool.query(
    `INSERT INTO status_privacy (user_id, mode, user_ids) VALUES ($1,$2,$3::uuid[])
     ON CONFLICT (user_id) DO UPDATE SET mode=$2, user_ids=$3::uuid[]`,
    [req.userId, p.data.mode, ids]);
  res.json({ ok: true });
});

// ---------- النشر ----------
// الجمهور + مفاتيحهم (بعد تطبيق الخصوصية) عشان التطبيق يشفّر الحالة لكل واحد
storiesRouter.get("/audience", async (req: AuthedRequest, res) => {
  const rows = await allowed(req.userId!);
  res.json(rows.map((r) => ({ id: r.id, publicKey: r.public_key })));
});

storiesRouter.post("/", postLimiter, async (req: AuthedRequest, res) => {
  const p = z.object({
    kind: z.enum(["image", "text"]),
    mediaId: uuid.optional(),
    ciphertext: z.string().min(1).max(200_000),
    audience: z.array(uuid).min(1).max(500),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "بيانات غير صالحة" });
  const me = req.userId!;

  // الصورة لازم ملف، والحالة النصية من غير ملف
  if ((p.data.kind === "image") !== !!p.data.mediaId)
    return res.status(400).json({ error: "بيانات غير صالحة" });
  if (p.data.mediaId &&
      !(await pool.query("SELECT 1 FROM media WHERE id=$1 AND owner_id=$2", [p.data.mediaId, me])).rowCount)
    return res.status(400).json({ error: "ملف غير صالح" });

  // السيرفر بيفرض الخصوصية: الجمهور لازم يكون جزء من المسموح لهم
  const ok = new Set((await allowed(me)).map((c) => c.id));
  const audience = [...new Set(p.data.audience)];
  if (!audience.every((id) => ok.has(id)))
    return res.status(400).json({ error: "جمهور غير مسموح حسب إعدادات الخصوصية" });
  if (!validPayload(p.data.ciphertext, [me, ...audience]))
    return res.status(400).json({ error: "الحالة لازم تتشفر لكل الجمهور" });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const s = await client.query(
      `INSERT INTO stories (user_id, kind, media_id, ciphertext, expires_at)
       VALUES ($1,$2,$3,$4, now() + interval '24 hours') RETURNING id, expires_at`,
      [me, p.data.kind, p.data.mediaId ?? null, p.data.ciphertext]);
    await client.query(
      "INSERT INTO story_audience (story_id, user_id) SELECT $1, unnest($2::uuid[])",
      [s.rows[0].id, audience]);
    await client.query("COMMIT");
    res.json({ id: s.rows[0].id, expiresAt: s.rows[0].expires_at });
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
});

// ---------- العرض ----------
storiesRouter.get("/", async (req: AuthedRequest, res) => {
  const { rows } = await pool.query(
    `SELECT s.id, s.user_id, u.name, u.phone, s.kind, s.media_id, s.ciphertext, s.created_at, s.expires_at,
       EXISTS (SELECT 1 FROM story_views v WHERE v.story_id=s.id AND v.viewer_id=$1) AS viewed
     FROM stories s JOIN users u ON u.id=s.user_id
     WHERE s.expires_at > now() AND s.ciphertext IS NOT NULL
       AND (s.user_id=$1 OR EXISTS (
         SELECT 1 FROM story_audience a WHERE a.story_id=s.id AND a.user_id=$1))
     ORDER BY s.created_at ASC LIMIT 300`, [req.userId]);
  res.json(rows);
});

storiesRouter.post("/:id/view", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  await pool.query(
    `INSERT INTO story_views (story_id, viewer_id)
     SELECT s.id, $2 FROM stories s
     JOIN story_audience a ON a.story_id=s.id AND a.user_id=$2
     WHERE s.id=$1 AND s.expires_at > now()
     ON CONFLICT DO NOTHING`, [id.data, req.userId]);
  res.json({ ok: true });
});

storiesRouter.get("/:id/views", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  if (!(await pool.query("SELECT 1 FROM stories WHERE id=$1 AND user_id=$2", [id.data, req.userId])).rowCount)
    return res.status(404).json({ error: "not found" });
  const { rows } = await pool.query(
    `SELECT u.id, u.name, u.phone, v.viewed_at
     FROM story_views v JOIN users u ON u.id=v.viewer_id
     WHERE v.story_id=$1 ORDER BY v.viewed_at DESC`, [id.data]);
  res.json(rows);
});

storiesRouter.delete("/:id", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  const r = await pool.query("DELETE FROM stories WHERE id=$1 AND user_id=$2 RETURNING id", [id.data, req.userId]);
  if (!r.rowCount) return res.status(404).json({ error: "not found" });
  res.json({ ok: true });
});
