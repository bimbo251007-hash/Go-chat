import { Router, Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { pool } from "./db.js";

const secret = () => process.env.JWT_SECRET!;
const sha = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const otpHash = (phone: string, code: string) =>
  crypto.createHmac("sha256", secret()).update(`${phone}:${code}`).digest("hex");
const safeEq = (a: string, b: string) => {
  const A = Buffer.from(a), B = Buffer.from(b);
  return A.length === B.length && crypto.timingSafeEqual(A, B);
};

// ---------- JWT (صلاحية قصيرة 15 دقيقة + Refresh Token) ----------
export const signAccess = (userId: string) =>
  jwt.sign({ sub: userId }, secret(), { algorithm: "HS256", expiresIn: "15m" });

export const verifyToken = (token: string): { sub: string; exp: number } | null => {
  try {
    const p = jwt.verify(token, secret(), { algorithms: ["HS256"] }) as jwt.JwtPayload;
    return typeof p.sub === "string" && p.exp ? { sub: p.sub, exp: p.exp } : null;
  } catch {
    return null;
  }
};

export interface AuthedRequest extends Request {
  userId?: string;
}

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const v = verifyToken((req.headers.authorization ?? "").replace("Bearer ", ""));
  if (!v) return res.status(401).json({ error: "unauthorized" });
  req.userId = v.sub;
  next();
}

async function issueSession(userId: string, family?: string) {
  const refresh = crypto.randomBytes(32).toString("base64url");
  await pool.query(
    `INSERT INTO refresh_tokens (user_id, family, token_hash, expires_at)
     VALUES ($1, COALESCE($2::uuid, gen_random_uuid()), $3, now() + interval '30 days')`,
    [userId, family ?? null, sha(refresh)]
  );
  return { token: signAccess(userId), refreshToken: refresh };
}

// ---------- Rate limiting ----------
const limiterOpts = { standardHeaders: true, legacyHeaders: false };
const ipLimiter = rateLimit({ ...limiterOpts, windowMs: 15 * 60_000, limit: 20,
  message: { error: "طلبات كتير، حاول بعد شوية" } });
const refreshLimiter = rateLimit({ ...limiterOpts, windowMs: 15 * 60_000, limit: 60,
  message: { error: "طلبات كتير، حاول بعد شوية" } });
const phoneLimiter = rateLimit({ ...limiterOpts, windowMs: 10 * 60_000, limit: 3,
  keyGenerator: (req) => "p:" + String(req.body?.phone ?? ""),
  message: { error: "طلبت كود كتير، استنى 10 دقايق" } });

// ---------- إرسال SMS ----------
async function sendSms(phone: string, code: string) {
  if (process.env.NODE_ENV !== "production") {
    console.log(`[DEV] OTP for ${phone}: ${code}`);
    return;
  }
  // TODO: اربط Twilio / Vonage هنا. الكود عمره ما بيتطبع في الإنتاج.
  throw new Error("SMS provider not configured");
}

const Phone = z.string().regex(/^\+[1-9]\d{7,14}$/);
export const authRouter = Router();

authRouter.post("/request-otp", ipLimiter, phoneLimiter, async (req, res) => {
  const p = z.object({ phone: Phone }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "رقم غير صالح (استخدم الصيغة الدولية +20...)" });

  const code = crypto.randomInt(100000, 1000000).toString();
  await pool.query(
    `INSERT INTO otps (phone, code_hash, expires_at, attempts)
     VALUES ($1,$2, now() + interval '5 minutes', 0)
     ON CONFLICT (phone) DO UPDATE
       SET code_hash=$2, expires_at=now() + interval '5 minutes', attempts=0`,
    [p.data.phone, otpHash(p.data.phone, code)]
  );
  try {
    await sendSms(p.data.phone, code);
  } catch (e) {
    console.error("SMS send failed");
    return res.status(503).json({ error: "تعذر إرسال الكود" });
  }
  res.json({ ok: true });
});

authRouter.post("/verify", ipLimiter, async (req, res) => {
  const p = z.object({
    phone: Phone,
    code: z.string().regex(/^\d{6}$/),
    name: z.string().trim().max(50).optional(),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "بيانات غير صالحة" });

  // زيادة المحاولات وقراءة الكود في عملية واحدة (بدون سباق)
  const { rows } = await pool.query(
    `UPDATE otps SET attempts = attempts + 1
     WHERE phone=$1 AND attempts < 5 AND expires_at > now()
     RETURNING code_hash`,
    [p.data.phone]
  );
  if (!rows[0] || !safeEq(rows[0].code_hash, otpHash(p.data.phone, p.data.code)))
    return res.status(400).json({ error: "الكود غلط أو منتهي" });

  await pool.query("DELETE FROM otps WHERE phone=$1", [p.data.phone]);
  const u = await pool.query(
    `INSERT INTO users (phone, name) VALUES ($1, $2::text)
     ON CONFLICT (phone) DO UPDATE SET name = COALESCE(NULLIF($2::text,''), users.name)
     RETURNING id, phone, name, avatar`,
    [p.data.phone, p.data.name ?? ""]
  );
  res.json({ ...(await issueSession(u.rows[0].id)), user: u.rows[0] });
});

// تجديد الجلسة مع تدوير التوكن + كشف إعادة الاستخدام (سرقة توكن)
authRouter.post("/refresh", refreshLimiter, async (req, res) => {
  const p = z.object({ refreshToken: z.string().min(20).max(200) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "bad request" });

  const { rows } = await pool.query(
    "SELECT id, user_id, family, expires_at, revoked FROM refresh_tokens WHERE token_hash=$1",
    [sha(p.data.refreshToken)]
  );
  const t = rows[0];
  if (!t) return res.status(401).json({ error: "unauthorized" });
  if (t.revoked) {
    // توكن اتستخدم قبل كده: احتمال سرقة، نلغي العيلة كلها
    await pool.query("UPDATE refresh_tokens SET revoked=true WHERE family=$1", [t.family]);
    return res.status(401).json({ error: "unauthorized" });
  }
  if (new Date(t.expires_at) < new Date()) return res.status(401).json({ error: "unauthorized" });

  const upd = await pool.query(
    "UPDATE refresh_tokens SET revoked=true WHERE id=$1 AND revoked=false RETURNING id", [t.id]);
  if (!upd.rowCount) return res.status(401).json({ error: "unauthorized" });
  res.json(await issueSession(t.user_id, t.family));
});

authRouter.post("/logout", refreshLimiter, async (req, res) => {
  const p = z.object({ refreshToken: z.string().max(200) }).safeParse(req.body);
  if (p.success) {
    await pool.query(
      `UPDATE refresh_tokens SET revoked=true
       WHERE family = (SELECT family FROM refresh_tokens WHERE token_hash=$1)`,
      [sha(p.data.refreshToken)]
    );
  }
  res.json({ ok: true });
});
