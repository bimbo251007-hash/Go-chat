import { Router } from "express";
import rateLimit from "express-rate-limit";
import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import { z } from "zod";
import { pool } from "./db.js";
import { requireAuth, verifyToken, AuthedRequest } from "./auth.js";
import { pushToUser } from "./push.js";

const uuid = z.string().uuid();
export const chatRouter = Router();
chatRouter.use(requireAuth);

const lookupLimiter = rateLimit({
  windowMs: 60 * 60_000, limit: 30, standardHeaders: true, legacyHeaders: false,
  keyGenerator: (req) => "u:" + (req as AuthedRequest).userId,
  message: { error: "طلبات بحث كتير، حاول بعدين" },
});

// ---------- مفاتيح التشفير العامة ----------
chatRouter.put("/keys", async (req: AuthedRequest, res) => {
  const p = z.object({ publicKey: z.string().max(100) }).safeParse(req.body);
  const buf = p.success ? Buffer.from(p.data.publicKey, "base64") : null;
  if (!p.success || !buf || buf.length !== 32 || buf.toString("base64") !== p.data.publicKey)
    return res.status(400).json({ error: "invalid key" });
  await pool.query("UPDATE users SET public_key=$1 WHERE id=$2", [p.data.publicKey, req.userId]);
  res.json({ ok: true });
});

// مفتاح مستخدم: متاح فقط لنفسه أو لمن يشاركه محادثة
chatRouter.get("/keys/:userId", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.userId);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  const { rows } = await pool.query(
    `SELECT u.public_key FROM users u
     WHERE u.id=$1 AND (u.id=$2 OR EXISTS (
       SELECT 1 FROM members a JOIN members b ON a.conversation_id=b.conversation_id
       WHERE a.user_id=$1 AND b.user_id=$2))`,
    [id.data, req.userId]
  );
  if (!rows[0]?.public_key) return res.status(404).json({ error: "no key" });
  res.json({ publicKey: rows[0].public_key });
});

// ---------- المستخدمين والمحادثات ----------
chatRouter.get("/users/by-phone", lookupLimiter, async (req: AuthedRequest, res) => {
  const phone = z.string().regex(/^\+[1-9]\d{7,14}$/).safeParse(req.query.phone);
  if (!phone.success) return res.status(400).json({ error: "رقم غير صالح" });
  const { rows } = await pool.query(
    "SELECT id, name, avatar FROM users WHERE phone=$1 AND id<>$2", [phone.data, req.userId]);
  if (!rows[0]) return res.status(404).json({ error: "المستخدم غير موجود" });
  res.json(rows[0]);
});

chatRouter.post("/conversations/direct", async (req: AuthedRequest, res) => {
  const p = z.object({ userId: uuid }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "invalid userId" });
  const me = req.userId!, other = p.data.userId;
  if (me === other) return res.status(400).json({ error: "invalid userId" });
  if (!(await pool.query("SELECT 1 FROM users WHERE id=$1", [other])).rowCount)
    return res.status(404).json({ error: "المستخدم غير موجود" });

  const existing = await pool.query(
    `SELECT c.id FROM conversations c
     JOIN members a ON a.conversation_id=c.id AND a.user_id=$1
     JOIN members b ON b.conversation_id=c.id AND b.user_id=$2
     WHERE c.type='direct' LIMIT 1`, [me, other]);
  if (existing.rows[0]) return res.json({ id: existing.rows[0].id });

  const c = await pool.query("INSERT INTO conversations (type) VALUES ('direct') RETURNING id");
  await pool.query("INSERT INTO members (conversation_id, user_id) VALUES ($1,$2),($1,$3)",
    [c.rows[0].id, me, other]);
  res.json({ id: c.rows[0].id });
});

chatRouter.get("/conversations", async (req: AuthedRequest, res) => {
  const { rows } = await pool.query(
    `SELECT c.id, c.type, c.name,
       (SELECT json_build_object('id',u.id,'name',u.name,'avatar',u.avatar,'phone',u.phone,
                'online', false, 'lastSeen', CASE WHEN u.hide_last_seen THEN NULL ELSE u.last_seen_at END)
          FROM members m2 JOIN users u ON u.id=m2.user_id
          WHERE c.type='direct' AND m2.conversation_id=c.id AND m2.user_id<>$1 LIMIT 1) AS peer,
       (SELECT count(*)::int FROM members mm WHERE mm.conversation_id=c.id) AS member_count,
       lm.last_message,
       (SELECT count(*)::int FROM messages g
          WHERE g.conversation_id=c.id AND g.sender_id<>$1 AND g.created_at > m.last_read_at
            AND g.deleted_at IS NULL AND (g.expires_at IS NULL OR g.expires_at > now())
            AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id=g.id AND h.user_id=$1)) AS unread,
       CASE WHEN c.type='direct' AND s.last_day >= (now() AT TIME ZONE 'UTC')::date - 1 THEN s.count ELSE 0 END AS streak
     FROM conversations c
     JOIN members m ON m.conversation_id=c.id AND m.user_id=$1
     LEFT JOIN streaks s ON s.conversation_id=c.id
     LEFT JOIN LATERAL (
       SELECT json_build_object('id',g.id,'sender_id',g.sender_id,'ciphertext',g.ciphertext,'type',g.type,
                                'created_at',g.created_at,'deleted',g.deleted_at IS NOT NULL) AS last_message
       FROM messages g
       WHERE g.conversation_id=c.id AND (g.expires_at IS NULL OR g.expires_at > now())
         AND g.created_at >= m.joined_at
         AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id=g.id AND h.user_id=$1)
       ORDER BY g.created_at DESC LIMIT 1) lm ON true
     ORDER BY COALESCE((lm.last_message->>'created_at')::timestamptz, c.created_at) DESC`,
    [req.userId]);
  for (const r of rows) if (r.peer) r.peer.online = isOnline(r.peer.id);
  res.json(rows);
});

chatRouter.get("/conversations/:id/messages", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  const q = z.object({
    before: z.string().datetime().optional(),
    limit: z.coerce.number().int().min(1).max(100).default(50),
  }).safeParse(req.query);
  if (!q.success) return res.status(400).json({ error: "bad query" });
  const ok = await pool.query(
    "SELECT 1 FROM members WHERE conversation_id=$1 AND user_id=$2", [id.data, req.userId]);
  if (!ok.rowCount) return res.status(403).json({ error: "forbidden" });
  const { rows } = await pool.query(
    `SELECT g.id, g.conversation_id, g.sender_id, g.type, g.status, g.created_at, g.expires_at,
            (g.deleted_at IS NOT NULL) AS deleted,
            CASE WHEN g.deleted_at IS NULL THEN g.ciphertext ELSE '' END AS ciphertext,
            CASE WHEN g.deleted_at IS NULL THEN g.media_id END AS media_id,
            CASE WHEN g.type='snap' THEN
              EXISTS (SELECT 1 FROM message_views v WHERE v.message_id=g.id
                      AND (v.user_id=$2 OR g.sender_id=$2)) END AS snap_viewed
     FROM messages g
     WHERE g.conversation_id=$1 AND (g.expires_at IS NULL OR g.expires_at > now())
       AND g.created_at >= (SELECT joined_at FROM members WHERE conversation_id=g.conversation_id AND user_id=$2)
       AND ($3::timestamptz IS NULL OR g.created_at < $3)
       AND NOT EXISTS (SELECT 1 FROM message_hidden h WHERE h.message_id=g.id AND h.user_id=$2)
     ORDER BY g.created_at DESC LIMIT $4`,
    [id.data, req.userId, q.data.before ?? null, q.data.limit]);
  res.json(rows);
});

chatRouter.post("/conversations/:id/read", async (req: AuthedRequest, res) => {
  const id = uuid.safeParse(req.params.id);
  if (!id.success) return res.status(400).json({ error: "bad id" });
  if (!(await markConversationRead(id.data, req.userId!))) return res.status(403).json({ error: "forbidden" });
  res.json({ ok: true });
});

// يحدّث آخر قراءة، ويعتبر الرسالة "اتقرأت" لما كل الأعضاء التانيين يقروها
export async function markConversationRead(convId: string, userId: string, upTo?: Date): Promise<boolean> {
  const up = await pool.query(
    `UPDATE members SET last_read_at = GREATEST(last_read_at, COALESCE($3::timestamptz, now()))
     WHERE conversation_id=$1 AND user_id=$2 RETURNING last_read_at`, [convId, userId, upTo ?? null]);
  if (!up.rowCount) return false;
  const upd = await pool.query(
    `UPDATE messages g SET status='read'
     WHERE g.conversation_id=$1 AND g.sender_id<>$2 AND g.status<>'read' AND g.created_at <= $3
       AND NOT EXISTS (SELECT 1 FROM members m WHERE m.conversation_id=g.conversation_id
                       AND m.user_id<>g.sender_id AND m.last_read_at < g.created_at)
     RETURNING g.id, g.sender_id`, [convId, userId, up.rows[0].last_read_at]);
  for (const r of upd.rows) sendTo(r.sender_id, { type: "read", messageId: r.id, conversationId: convId });
  return true;
}

// ---------- WebSocket ----------
const clients = new Map<string, Set<WebSocket>>();
export const sendTo = (userId: string, payload: unknown) =>
  clients.get(userId)?.forEach((s) => s.readyState === WebSocket.OPEN && s.send(JSON.stringify(payload)));
export const isOnline = (userId: string) => (clients.get(userId)?.size ?? 0) > 0;

export async function memberIds(conversationId: string): Promise<string[]> {
  const r = await pool.query("SELECT user_id FROM members WHERE conversation_id=$1", [conversationId]);
  return r.rows.map((x) => x.user_id);
}
export const notifyMembers = async (conversationId: string, payload: unknown, except?: string) =>
  (await memberIds(conversationId)).filter((id) => id !== except).forEach((id) => sendTo(id, payload));

const SendMsg = z.object({
  type: z.literal("send"),
  conversationId: uuid,
  ciphertext: z.string().min(1).max(100_000),
  msgType: z.enum(["text", "reply", "image", "video", "audio", "file", "snap"]).default("text"),
  expiresInSec: z.number().int().positive().max(7 * 86400).optional(),
  tempId: z.string().max(64).optional(),
  mediaId: uuid.optional(),
});
const ReadMsg = z.object({ type: z.literal("read"), messageId: uuid });
const Typing = z.object({ type: z.literal("typing"), conversationId: uuid, typing: z.boolean() });
const Screenshot = z.object({ type: z.literal("screenshot"), messageId: uuid });

// السيرفر مش بيشوف النص، لكن بيرفض أي رسالة مش متشفرة لكل أعضاء المحادثة
export function validPayload(ct: string, memberIds: string[]): boolean {
  try {
    const o = JSON.parse(ct);
    return o?.v === 1 && typeof o.epk === "string" && !!o.r && typeof o.r === "object" &&
      memberIds.every((id) => typeof o.r[id] === "string");
  } catch {
    return false;
  }
}

// رسائل الفردي اللي كانت مستنية المستخدم يفتح: تتحول "وصلت" ويتبلّغ المرسلين
async function markDelivered(userId: string) {
  const { rows } = await pool.query(
    `UPDATE messages g SET status='delivered'
     FROM conversations c
     WHERE c.id=g.conversation_id AND c.type='direct' AND g.status='sent' AND g.sender_id<>$1
       AND EXISTS (SELECT 1 FROM members m WHERE m.conversation_id=g.conversation_id AND m.user_id=$1)
     RETURNING g.id, g.sender_id, g.conversation_id`, [userId]);
  for (const r of rows) sendTo(r.sender_id, { type: "delivered", messageId: r.id, conversationId: r.conversation_id });
}

// Streak: يوم بيتحسب لما الاتنين يبعتوا Snap في نفس اليوم (UTC)، والأيام لازم تتتابع
async function recordSnapStreak(convId: string, uid: string, direct: boolean) {
  if (!direct) return;
  await pool.query("INSERT INTO snap_days (conversation_id, day, user_id) VALUES ($1,(now() AT TIME ZONE 'UTC')::date,$2) ON CONFLICT DO NOTHING",
    [convId, uid]);
  await pool.query(
    `WITH today AS (SELECT (now() AT TIME ZONE 'UTC')::date AS d),
     both_sent AS (
       SELECT 1 FROM snap_days, today WHERE conversation_id=$1 AND day=today.d HAVING count(DISTINCT user_id) >= 2)
     INSERT INTO streaks (conversation_id, count, last_day)
     SELECT $1, 1, today.d FROM today WHERE EXISTS (SELECT 1 FROM both_sent)
     ON CONFLICT (conversation_id) DO UPDATE SET
       count = CASE WHEN streaks.last_day = EXCLUDED.last_day THEN streaks.count
                    WHEN streaks.last_day = EXCLUDED.last_day - 1 THEN streaks.count + 1
                    ELSE 1 END,
       last_day = EXCLUDED.last_day`, [convId]);
}

// إشعار للأجهزة بدون أي محتوى (راجع push.ts)
export function notifyOffline(userId: string, conversationId: string) {
  pushToUser(userId, conversationId).catch(() => console.error("push failed"));
}

export function attachWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws", maxPayload: 256 * 1024 });
  const alive = new WeakSet<WebSocket>();

  wss.on("connection", (ws) => {
    alive.add(ws);
    let userId: string | null = null;
    let expTimer: NodeJS.Timeout | undefined;
    // التوكن بيتبعت في أول رسالة (مش في الـ URL عشان ما يظهرش في اللوجز)
    const authTimer = setTimeout(() => { if (!userId) ws.close(4401, "auth timeout"); }, 5000);
    const bucket = { tokens: 20, last: Date.now() };
    const allow = () => {
      const now = Date.now();
      bucket.tokens = Math.min(20, bucket.tokens + (now - bucket.last) / 500);
      bucket.last = now;
      if (bucket.tokens < 1) return false;
      bucket.tokens -= 1;
      return true;
    };

    ws.on("pong", () => alive.add(ws));

    ws.on("message", async (raw) => {
      if (!allow()) return ws.close(4429, "rate limited");
      let data: any;
      try { data = JSON.parse(raw.toString()); } catch { return ws.close(4400, "bad json"); }

      if (!userId) {
        const v = data?.type === "auth" && typeof data.token === "string" ? verifyToken(data.token) : null;
        if (!v) return ws.close(4401, "unauthorized");
        userId = v.sub;
        clearTimeout(authTimer);
        if (!clients.has(userId)) clients.set(userId, new Set());
        clients.get(userId)!.add(ws);
        // نقفل الاتصال لما التوكن ينتهي، والتطبيق يجدد ويرجع يتصل
        expTimer = setTimeout(() => ws.close(4401, "token expired"), Math.max(0, v.exp * 1000 - Date.now()));
        ws.send(JSON.stringify({ type: "authed" }));
        markDelivered(userId).catch(() => {});
        return;
      }

      const uid = userId;
      try {
        if (data.type === "send") {
          const m = SendMsg.parse(data);
          const members = await pool.query(
            "SELECT user_id FROM members WHERE conversation_id=$1", [m.conversationId]);
          const ids: string[] = members.rows.map((r) => r.user_id);
          if (!ids.includes(uid)) return ws.send(JSON.stringify({ type: "error", error: "forbidden" }));
          if (!validPayload(m.ciphertext, ids))
            // في الجروبات: العضوية ممكن تكون اتغيرت، التطبيق يحدّث الأعضاء ويعيد التشفير
            return ws.send(JSON.stringify({ type: "error", error: "members_changed",
              conversationId: m.conversationId, tempId: m.tempId }));

          // الرسائل النصية من غير ملف، وغير كده لازم ملف يخص المرسل
          const isMedia = m.msgType !== "text" && m.msgType !== "reply";
          if (isMedia !== !!m.mediaId)
            return ws.send(JSON.stringify({ type: "error", error: "media mismatch" }));
          if (m.mediaId && !(await pool.query(
              "SELECT 1 FROM media WHERE id=$1 AND owner_id=$2", [m.mediaId, uid])).rowCount)
            return ws.send(JSON.stringify({ type: "error", error: "invalid media" }));

          // Snap بيتمسح لو محدش فتحه خلال 24 ساعة
          const expires = m.msgType === "snap" ? Math.min(m.expiresInSec ?? 86400, 86400) : m.expiresInSec;
          const ins = await pool.query(
            `INSERT INTO messages (conversation_id, sender_id, ciphertext, type, expires_at, media_id)
             VALUES ($1,$2,$3,$4, CASE WHEN $5::int IS NULL THEN NULL ELSE now() + ($5::int * interval '1 second') END, $6)
             RETURNING id, conversation_id, sender_id, ciphertext, type, status, created_at, expires_at, media_id`,
            [m.conversationId, uid, m.ciphertext, m.msgType, expires ?? null, m.mediaId ?? null]);
          const msg = ins.rows[0];
          const others = ids.filter((id) => id !== uid);
          // "وصلت": في المحادثات الفردية لو الطرف التاني أونلاين
          let status = msg.status;
          if (others.length === 1 && isOnline(others[0])) {
            await pool.query("UPDATE messages SET status='delivered' WHERE id=$1 AND status='sent'", [msg.id]);
            status = msg.status = "delivered";
          }
          ws.send(JSON.stringify({ type: "ack", tempId: m.tempId, id: msg.id, createdAt: msg.created_at, status }));
          others.forEach((id) => sendTo(id, { type: "message", message: msg }));
          others.filter((id) => !isOnline(id)).forEach((id) => notifyOffline(id, msg.conversation_id));
          if (m.msgType === "snap") await recordSnapStreak(m.conversationId, uid, others.length === 1);
        } else if (data.type === "read") {
          const r = ReadMsg.parse(data);
          const msg = await pool.query(
            `SELECT g.conversation_id, g.created_at FROM messages g
             JOIN members m ON m.conversation_id=g.conversation_id AND m.user_id=$2
             WHERE g.id=$1 AND g.sender_id<>$2`, [r.messageId, uid]);
          if (msg.rows[0]) await markConversationRead(msg.rows[0].conversation_id, uid, msg.rows[0].created_at);
        } else if (data.type === "typing") {
          const t = Typing.parse(data);
          const ids = await memberIds(t.conversationId);
          if (ids.includes(uid))
            ids.filter((id) => id !== uid).forEach((id) =>
              sendTo(id, { type: "typing", conversationId: t.conversationId, userId: uid, typing: t.typing }));
        } else if (data.type === "screenshot") {
          // التطبيق بيبلّغ لو اكتشف لقطة شاشة لـ Snap (الكشف نفسه على الجهاز، السيرفر بس بيوصّل التنبيه)
          const s = Screenshot.parse(data);
          const g = await pool.query(
            `SELECT g.sender_id, g.conversation_id FROM messages g
             JOIN members m ON m.conversation_id=g.conversation_id AND m.user_id=$2
             WHERE g.id=$1 AND g.type='snap' AND g.sender_id<>$2`, [s.messageId, uid]);
          if (g.rows[0]) sendTo(g.rows[0].sender_id,
            { type: "screenshot", messageId: s.messageId, conversationId: g.rows[0].conversation_id, userId: uid });
        }
      } catch {
        ws.send(JSON.stringify({ type: "error", error: "bad request" }));
      }
    });

    ws.on("close", () => {
      clearTimeout(authTimer);
      if (expTimer) clearTimeout(expTimer);
      if (userId) {
        clients.get(userId)?.delete(ws);
        if (!clients.get(userId)?.size) {
          clients.delete(userId);
          pool.query("UPDATE users SET last_seen_at=now() WHERE id=$1", [userId]).catch(() => {});
        }
      }
    });
  });

  // Heartbeat: نقفل الاتصالات الميتة
  setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!alive.has(ws)) return ws.terminate();
      alive.delete(ws);
      ws.ping();
    });
  }, 30_000);

  // مسح الرسائل المنتهية والستوريز
  setInterval(() => {
    pool.query("DELETE FROM messages WHERE expires_at IS NOT NULL AND expires_at < now()").catch(console.error);
    pool.query("DELETE FROM stories WHERE expires_at < now()").catch(console.error);
  }, 60_000);
}
