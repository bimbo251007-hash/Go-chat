import "dotenv/config";
import "express-async-errors";
import express, { NextFunction, Request, Response } from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import http from "http";
import { pool } from "./db.js";
import { authRouter } from "./auth.js";
import { chatRouter, attachWebSocket } from "./chat.js";
import { mediaRouter, MEDIA_DIR, purgeViewedSnaps } from "./media.js";
import { storiesRouter } from "./stories.js";
import { socialRouter } from "./social.js";
import fs from "fs";
import path from "path";

// رفض التشغيل بإعدادات ضعيفة
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error("JWT_SECRET لازم يكون 32 حرف على الأقل (openssl rand -hex 48)");
  process.exit(1);
}
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL مطلوب");
  process.exit(1);
}

const app = express();
app.disable("x-powered-by");
if (process.env.TRUST_PROXY) app.set("trust proxy", Number(process.env.TRUST_PROXY));
app.use(helmet());
app.use(express.json({ limit: "100kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false,
  message: { error: "طلبات كتير" } }));

app.get("/health", (_req, res) => res.json({ ok: true }));
app.use("/auth", authRouter);
app.use("/media", mediaRouter);
app.use("/stories", storiesRouter);
app.use("/", socialRouter);
app.use("/", chatRouter);

app.use((_req, res) => res.status(404).json({ error: "not found" }));
// ما بنكشفش تفاصيل الأخطاء للعميل
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err?.status && err.status < 500 ? err.status : 500;
  if (status === 500) console.error(err?.message ?? err);
  res.status(status).json({ error: status === 500 ? "internal error" : "bad request" });
});

process.on("unhandledRejection", (e) => console.error("unhandledRejection", e));

const server = http.createServer(app);
attachWebSocket(server);

// تنظيف الأكواد والتوكنز المنتهية
setInterval(() => {
  pool.query("DELETE FROM otps WHERE expires_at < now()").catch(console.error);
  pool.query("DELETE FROM refresh_tokens WHERE expires_at < now() - interval '7 days'").catch(console.error);
}, 3_600_000);

// مسح الملفات اللي مفيش رسالة بتشاور عليها (رسائل اتمسحت أو رفع ماكملش)
setInterval(async () => {
  try {
    const { rows } = await pool.query(
      `DELETE FROM media m WHERE m.created_at < now() - interval '1 hour'
       AND NOT EXISTS (SELECT 1 FROM messages g WHERE g.media_id = m.id)
       AND NOT EXISTS (SELECT 1 FROM stories s WHERE s.media_id = m.id) RETURNING m.id`);
    for (const r of rows) await fs.promises.unlink(path.join(MEDIA_DIR, r.id)).catch(() => {});
  } catch (e) { console.error("media cleanup failed"); }
}, 600_000);

setInterval(() => purgeViewedSnaps().catch(() => console.error("snap cleanup failed")), 30_000);

const port = Number(process.env.PORT ?? 3000);
server.listen(port, () => console.log(`Server running on :${port}`));
