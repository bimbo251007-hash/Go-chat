import crypto from "crypto";
import fs from "fs";
import { pool } from "./db.js";

// إشعارات FCM (HTTP v1) من غير أي مكتبة: توقيع JWT بـ crypto وطلبات بـ fetch.
// الإشعار عام جدًا ("رسالة جديدة") ومفيهوش أي محتوى، لأن الرسايل مشفرة ومحدش على السيرفر يقدر يقراها.
// الإعداد: FCM_SERVICE_ACCOUNT=/path/to/service-account.json في .env
type SA = { project_id: string; client_email: string; private_key: string };
let sa: SA | null | undefined;
const account = (): SA | null => {
  if (sa !== undefined) return sa;
  try { sa = process.env.FCM_SERVICE_ACCOUNT
      ? JSON.parse(fs.readFileSync(process.env.FCM_SERVICE_ACCOUNT, "utf8")) : null; }
  catch { console.error("FCM_SERVICE_ACCOUNT غير صالح"); sa = null; }
  return sa;
};

const b64u = (b: Buffer | string) => Buffer.from(b).toString("base64url");
let cached: { token: string; exp: number } | null = null;

async function accessToken(a: SA): Promise<string> {
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const body = b64u(JSON.stringify({
    iss: a.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 }));
  const sig = crypto.createSign("RSA-SHA256").update(`${head}.${body}`).sign(a.private_key).toString("base64url");
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: `${head}.${body}.${sig}` }),
  });
  if (!r.ok) throw new Error("fcm auth failed");
  const j: any = await r.json();
  cached = { token: j.access_token, exp: Date.now() + (j.expires_in ?? 3600) * 1000 };
  return cached.token;
}

export async function pushToUser(userId: string, conversationId: string) {
  const { rows } = await pool.query("SELECT token FROM devices WHERE user_id=$1", [userId]);
  if (!rows.length) return;
  const a = account();
  if (!a) {
    if (process.env.NODE_ENV !== "production") console.log(`[DEV] push -> ${rows.length} device(s) of ${userId}`);
    return;
  }
  const at = await accessToken(a);
  for (const { token } of rows) {
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${a.project_id}/messages:send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${at}`, "Content-Type": "application/json" },
      body: JSON.stringify({ message: {
        token,
        notification: { title: "شات", body: "رسالة جديدة" },
        data: { conversationId },
        android: { priority: "HIGH" },
        apns: { headers: { "apns-priority": "10" }, payload: { aps: { sound: "default" } } },
      } }),
    });
    // التوكن مبقاش صالح (اتمسح التطبيق مثلًا): نشيله
    if (r.status === 404 || r.status === 400) {
      const t: any = await r.json().catch(() => ({}));
      if (JSON.stringify(t).includes("UNREGISTERED") || r.status === 404)
        await pool.query("DELETE FROM devices WHERE token=$1", [token]);
    }
  }
}
