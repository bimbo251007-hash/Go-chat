import 'api.dart';
import 'crypto.dart';
import 'push.dart';
import 'socket.dart';

/// بعد تسجيل الدخول أو فتح التطبيق: جهّز التشفير، ارفع المفتاح العام، وافتح الاتصال
Future<void> startSession() async {
  await E2E.I.init(Api.I.userId!);
  try {
    await Api.I.putKey(E2E.I.myPublicB64);
  } catch (_) {}
  ChatSocket.I.connect();
  Push.init(); // من غير await: مفيش حاجة تستنى الإشعارات
}
