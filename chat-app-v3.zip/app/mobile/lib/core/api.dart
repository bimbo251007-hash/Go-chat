import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'config.dart';

class Api {
  static final Api I = Api._();
  Api._();

  final _store = const FlutterSecureStorage();
  String? token, refreshToken, userId;
  Future<bool>? _refreshing;

  Future<void> load() async {
    token = await _store.read(key: 'token');
    refreshToken = await _store.read(key: 'refresh');
    userId = await _store.read(key: 'userId');
  }

  Future<void> _save() async {
    final m = {'token': token, 'refresh': refreshToken, 'userId': userId};
    for (final e in m.entries) {
      if (e.value == null) {
        await _store.delete(key: e.key);
      } else {
        await _store.write(key: e.key, value: e.value);
      }
    }
  }

  Future<void> _clear() async {
    token = null;
    refreshToken = null;
    userId = null;
    await _save();
  }

  Future<void> logout() async {
    final rt = refreshToken;
    if (rt != null) {
      try {
        await http.post(Uri.parse('$apiBase/auth/logout'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'refreshToken': rt}));
      } catch (_) {}
    }
    await _clear(); // مفاتيح التشفير بتفضل محفوظة لكل حساب
  }

  Map<String, String> get _h => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  // ---- تجديد الجلسة تلقائيًا ----
  Future<bool> refreshNow() =>
      _refreshing ??= _doRefresh().whenComplete(() => _refreshing = null);

  Future<bool> _doRefresh() async {
    final rt = refreshToken;
    if (rt == null) return false;
    try {
      final r = await http.post(Uri.parse('$apiBase/auth/refresh'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'refreshToken': rt}));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        token = d['token'];
        refreshToken = d['refreshToken'];
        await _save();
        return true;
      }
      if (r.statusCode == 401) await _clear(); // الجلسة انتهت فعلًا
    } catch (_) {} // مشكلة شبكة: نحافظ على الجلسة
    return false;
  }

  dynamic _decode(http.Response r) {
    dynamic d;
    try {
      d = jsonDecode(r.body);
    } catch (_) {
      throw Exception('طلبات كتير أو خطأ في السيرفر، حاول بعد شوية');
    }
    if (r.statusCode == 401) throw Exception('انتهت الجلسة، سجّل دخول تاني');
    if (r.statusCode >= 400) throw Exception(d is Map ? (d['error'] ?? 'خطأ') : 'خطأ');
    return d;
  }

  Future<dynamic> _call(Future<http.Response> Function() f) async {
    var r = await f();
    if (r.statusCode == 401 && refreshToken != null && await refreshNow()) r = await f();
    return _decode(r);
  }

  Future<dynamic> _get(String p) => _call(() => http.get(Uri.parse('$apiBase$p'), headers: _h));
  Future<dynamic> _post(String p, Map b) =>
      _call(() => http.post(Uri.parse('$apiBase$p'), headers: _h, body: jsonEncode(b)));
  Future<dynamic> _put(String p, Map b) =>
      _call(() => http.put(Uri.parse('$apiBase$p'), headers: _h, body: jsonEncode(b)));

  Future<void> requestOtp(String phone) => _post('/auth/request-otp', {'phone': phone});

  Future<void> verify(String phone, String code, String name) async {
    final d = await _post('/auth/verify', {'phone': phone, 'code': code, 'name': name});
    token = d['token'];
    refreshToken = d['refreshToken'];
    userId = d['user']['id'];
    await _save();
  }

  // الملفات بتترفع مشفرة بالفعل (السيرفر مش بيشوف محتواها)
  Future<String> uploadBlob(Uint8List bytes) async {
    final r = await _call(() => http.post(Uri.parse('$apiBase/media'),
        headers: {..._h, 'Content-Type': 'application/octet-stream'}, body: bytes));
    return r['id'];
  }

  Future<Uint8List> downloadBlob(String id) async {
    Future<http.Response> go() => http.get(Uri.parse('$apiBase/media/$id'), headers: _h);
    var r = await go();
    if (r.statusCode == 401 && refreshToken != null && await refreshNow()) r = await go();
    if (r.statusCode != 200) throw Exception('تعذر تحميل الملف');
    return r.bodyBytes;
  }

  Future<void> putKey(String pub) => _put('/keys', {'publicKey': pub});
  Future<String> getKey(String userId) async => (await _get('/keys/$userId'))['publicKey'];

  Future<List<dynamic>> conversations() async => await _get('/conversations');

  // ---- الستوريز ----
  Future<List<dynamic>> storyAudience() async => await _get('/stories/audience');
  Future<void> postStory(String kind, String? mediaId, String ciphertext, List<String> audience) =>
      _post('/stories', {
        'kind': kind,
        if (mediaId != null) 'mediaId': mediaId,
        'ciphertext': ciphertext,
        'audience': audience,
      });
  Future<Map<String, dynamic>> storyPrivacy() async =>
      Map<String, dynamic>.from(await _get('/stories/privacy'));
  Future<void> setStoryPrivacy(String mode, List<String> ids) =>
      _put('/stories/privacy', {'mode': mode, 'userIds': ids});
  Future<List<dynamic>> storyContacts() async => await _get('/stories/contacts');
  Future<List<dynamic>> storiesFeed() async => await _get('/stories');
  Future<void> viewStory(String id) => _post('/stories/$id/view', {});
  Future<List<dynamic>> storyViews(String id) async => await _get('/stories/$id/views');
  Future<void> deleteStory(String id) async {
    await _call(() => http.delete(Uri.parse('$apiBase/stories/$id'), headers: _h));
  }
  Future<List<dynamic>> messages(String convId, {String? before}) async => await _get(
      '/conversations/$convId/messages${before != null ? '?before=${Uri.encodeQueryComponent(before)}' : ''}');

  Future<void> _delete(String p) async {
    await _call(() => http.delete(Uri.parse('$apiBase$p'), headers: _h));
  }

  // ---- الجروبات ----
  Future<String> createGroup(String name, List<String> memberIds) async =>
      (await _post('/conversations/group', {'name': name, 'memberIds': memberIds}))['id'];
  Future<List<dynamic>> members(String convId) async => await _get('/conversations/$convId/members');
  Future<void> addMembers(String convId, List<String> ids) =>
      _post('/conversations/$convId/members', {'userIds': ids});
  Future<void> removeMember(String convId, String userId) =>
      _delete('/conversations/$convId/members/$userId'); // نفس الدالة لمغادرة الجروب (userId = أنا)
  Future<void> renameGroup(String convId, String name) async {
    await _call(() => http.patch(Uri.parse('$apiBase/conversations/$convId'),
        headers: _h, body: jsonEncode({'name': name})));
  }
  Future<void> setRole(String convId, String userId, String role) =>
      _put('/conversations/$convId/members/$userId/role', {'role': role});

  // ---- الرسائل والتواجد والبروفايل ----
  Future<void> deleteMessage(String id, {required bool forEveryone}) =>
      _delete('/messages/$id?scope=${forEveryone ? 'everyone' : 'me'}');
  Future<Map<String, dynamic>> presence(String userId) async =>
      Map<String, dynamic>.from(await _get('/users/$userId/presence'));
  Future<Map<String, dynamic>> me() async => Map<String, dynamic>.from(await _get('/me'));
  Future<Map<String, dynamic>> updateMe({String? name, String? about, bool? hideLastSeen}) async =>
      Map<String, dynamic>.from(await _put('/me', {
        if (name != null) 'name': name,
        if (about != null) 'about': about,
        if (hideLastSeen != null) 'hideLastSeen': hideLastSeen,
      }));
  Future<void> unregisterDevice(String token) async {
    await _call(() => http.delete(Uri.parse('$apiBase/devices'), headers: _h, body: jsonEncode({'token': token})));
  }
  Future<void> registerDevice(String token, String platform) =>
      _put('/devices', {'token': token, 'platform': platform});

  Future<Map<String, dynamic>> lookup(String phone) async => Map<String, dynamic>.from(
      await _get('/users/by-phone?phone=${Uri.encodeQueryComponent(phone)}'));

  Future<String> openDirect(String userId) async =>
      (await _post('/conversations/direct', {'userId': userId}))['id'];
}
