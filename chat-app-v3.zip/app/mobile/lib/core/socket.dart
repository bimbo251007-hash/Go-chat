import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'api.dart';
import 'config.dart';

class ChatSocket {
  static final ChatSocket I = ChatSocket._();
  ChatSocket._();

  WebSocketChannel? _ch;
  bool _closed = true;
  bool ready = false;
  final _ctrl = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get events => _ctrl.stream;

  Future<void> connect() async {
    if (Api.I.refreshToken == null) return;
    _closed = false;
    await Api.I.refreshNow(); // توكن طازة قبل كل اتصال
    final t = Api.I.token;
    if (t == null || _closed) return;

    ready = false;
    _ch?.sink.close();
    final ch = WebSocketChannel.connect(Uri.parse('$wsBase/ws'));
    _ch = ch;
    ch.sink.add(jsonEncode({'type': 'auth', 'token': t})); // التوكن مش في الـ URL
    void lost() {
      if (!identical(_ch, ch)) return;
      ready = false;
      _retry();
    }

    ch.stream.listen(
      (e) {
        final m = Map<String, dynamic>.from(jsonDecode(e as String));
        if (m['type'] == 'authed') ready = true;
        _ctrl.add(m);
      },
      onDone: lost,
      onError: (_) => lost(),
    );
  }

  void _retry() {
    if (_closed) return;
    Future.delayed(const Duration(seconds: 3), () {
      if (!_closed) connect();
    });
  }

  bool send(Map<String, dynamic> m) {
    if (!ready || _ch == null) return false;
    _ch!.sink.add(jsonEncode(m));
    return true;
  }

  void disconnect() {
    _closed = true;
    ready = false;
    _ch?.sink.close();
    _ch = null;
  }
}
