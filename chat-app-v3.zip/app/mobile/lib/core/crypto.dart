import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

enum KeyStatus { fresh, same, changed }

/// تشفير طرف-لطرف:
/// - مفتاح هوية X25519 لكل مستخدم، الخاص بيتخزن في Keystore/Keychain ومبيسيبش الجهاز.
/// - كل رسالة: مفتاح مؤقت + مفتاح الهوية (يثبّت هوية المرسل) -> HKDF -> ChaCha20-Poly1305.
/// - الرسالة بتتشفر مرة لكل عضو (ومنهم المرسل نفسه عشان يشوف تاريخه).
/// - AAD بيربط الرسالة بالمحادثة والمرسل (يمنع نقلها لمحادثة تانية).
/// تنبيه: ده مش Double Ratchet، يعني مفيش Forward Secrecy كامل (راجع SECURITY.md).
class E2E {
  static final E2E I = E2E._();
  E2E._();

  final _x = X25519();
  final _aead = Chacha20.poly1305Aead();
  final _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  final _store = const FlutterSecureStorage();

  late SimpleKeyPair _kp;
  late String myPublicB64;
  String? _uid;

  Future<void> init(String userId) async {
    _uid = userId;
    final k = 'e2e_priv_$userId'; // مفتاح منفصل لكل حساب
    var seedB64 = await _store.read(key: k);
    if (seedB64 == null) {
      final r = Random.secure();
      final seed = Uint8List.fromList(List.generate(32, (_) => r.nextInt(256)));
      seedB64 = base64Encode(seed);
      await _store.write(key: k, value: seedB64);
    }
    _kp = await _x.newKeyPairFromSeed(base64Decode(seedB64)) as SimpleKeyPair;
    myPublicB64 = base64Encode((await _kp.extractPublicKey()).bytes);
  }

  SimplePublicKey _pub(String b64) =>
      SimplePublicKey(base64Decode(b64), type: KeyPairType.x25519);

  Future<List<int>> _dh(KeyPair mine, String theirPubB64) async =>
      (await _x.sharedSecretKey(keyPair: mine, remotePublicKey: _pub(theirPubB64))).extractBytes();

  Future<SecretKey> _key(List<int> dh1, List<int> dh2, String epk) => _hkdf.deriveKey(
        secretKey: SecretKey([...dh1, ...dh2]),
        nonce: const <int>[],
        info: utf8.encode('chat-v1|$epk'),
      );

  Future<String> encrypt({
    required String plaintext,
    required Map<String, String> recipients, // userId -> publicKey(b64)
    required String convId,
  }) async {
    final eph = await _x.newKeyPair();
    final epk = base64Encode((await eph.extractPublicKey()).bytes);
    final out = <String, String>{};
    for (final e in recipients.entries) {
      final dh1 = await _dh(eph, e.value); // مفتاح مؤقت × مفتاح المستلم
      final dh2 = await _dh(_kp, e.value); // هويتي × مفتاح المستلم (يثبت المرسل)
      final key = await _key(dh1, dh2, epk);
      final box = await _aead.encrypt(utf8.encode(plaintext),
          secretKey: key, aad: utf8.encode('$convId|$_uid'));
      out[e.key] = base64Encode(box.concatenation());
    }
    return jsonEncode({'v': 1, 'epk': epk, 'r': out});
  }

  Future<String?> decrypt({
    required String payload,
    required String convId,
    required String senderId,
    required String senderPubB64,
  }) async {
    try {
      final m = jsonDecode(payload) as Map<String, dynamic>;
      final epk = m['epk'] as String;
      final mine = (m['r'] as Map)[_uid] as String?;
      if (mine == null) return null;
      final dh1 = await _dh(_kp, epk);
      final dh2 = await _dh(_kp, senderPubB64);
      final key = await _key(dh1, dh2, epk);
      final box = SecretBox.fromConcatenation(base64Decode(mine), nonceLength: 12, macLength: 16);
      final clear = await _aead.decrypt(box,
          secretKey: key, aad: utf8.encode('$convId|$senderId'));
      return utf8.decode(clear);
    } catch (_) {
      return null; // فشل التحقق = رسالة متلاعب بيها أو مش ليّ
    }
  }

  /// رقم أمان لمقارنته مع الطرف التاني (بيكشف تلاعب السيرفر بالمفاتيح)
  Future<String> fingerprint(String a, String b) async {
    final parts = [a, b]..sort();
    final h = (await Sha256().hash(utf8.encode(parts.join('|')))).bytes;
    return List.generate(12, (i) {
      final v = ((h[i * 2] << 8) | h[i * 2 + 1]) % 100000;
      return v.toString().padLeft(5, '0');
    }).join(' ');
  }

  /// TOFU: نثبّت أول مفتاح نشوفه لكل شخص، ونحذّر لو اتغير
  Future<KeyStatus> checkPeer(String peerId, String pub) async {
    final k = 'peer_${_uid}_$peerId';
    final old = await _store.read(key: k);
    if (old == null) {
      await _store.write(key: k, value: pub);
      return KeyStatus.fresh;
    }
    return old == pub ? KeyStatus.same : KeyStatus.changed;
  }

  Future<void> acceptPeer(String peerId, String pub) =>
      _store.write(key: 'peer_${_uid}_$peerId', value: pub);

  /// تشفير ملف بمفتاح عشوائي جديد لكل ملف. المفتاح بيتبعت جوه رسالة E2E.
  Future<EncBlob> encryptBlob(Uint8List data) async {
    final key = await _aead.newSecretKey();
    final box = await _aead.encrypt(data, secretKey: key, aad: utf8.encode('blob-v1'));
    return EncBlob(Uint8List.fromList(box.concatenation()), base64Encode(await key.extractBytes()));
  }

  /// null = الملف اتعدّل أو المفتاح غلط
  Future<Uint8List?> decryptBlob(Uint8List blob, String keyB64) async {
    try {
      final box = SecretBox.fromConcatenation(blob, nonceLength: 12, macLength: 16);
      final clear = await _aead.decrypt(box,
          secretKey: SecretKey(base64Decode(keyB64)), aad: utf8.encode('blob-v1'));
      return Uint8List.fromList(clear);
    } catch (_) {
      return null;
    }
  }
}

class EncBlob {
  final Uint8List blob;
  final String key;
  EncBlob(this.blob, this.key);
}
