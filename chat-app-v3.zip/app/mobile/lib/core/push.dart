import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'api.dart';

/// تسجيل الجهاز للإشعارات. لو Firebase مش متظبط (مفيش google-services.json) التطبيق بيكمل عادي من غير إشعارات.
class Push {
  static String? _token;
  static bool _inited = false;

  static Future<void> init() async {
    try {
      if (!_inited) {
        await Firebase.initializeApp();
        _inited = true;
        FirebaseMessaging.instance.onTokenRefresh.listen(_register);
      }
      final m = FirebaseMessaging.instance;
      await m.requestPermission();
      final t = await m.getToken();
      if (t != null) await _register(t);
    } catch (_) {}
  }

  static Future<void> _register(String t) async {
    _token = t;
    try {
      await Api.I.registerDevice(t, Platform.isIOS ? 'ios' : 'android');
    } catch (_) {}
  }

  /// عند تسجيل الخروج: الجهاز ميستقبلش إشعارات الحساب ده
  static Future<void> unregister() async {
    final t = _token;
    if (t == null) return;
    try {
      await Api.I.unregisterDevice(t);
    } catch (_) {}
  }
}
