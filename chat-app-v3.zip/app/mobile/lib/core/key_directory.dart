import 'dart:convert';
import 'api.dart';
import 'crypto.dart';

/// كاش للمفاتيح العامة (بيتجاب من السيرفر مرة لكل شخص في الجلسة)
class KeyDirectory {
  static final KeyDirectory I = KeyDirectory._();
  KeyDirectory._();
  final Map<String, String> _keys = {};

  void put(String userId, String pub) => _keys[userId] = pub;

  Future<String?> key(String userId) async {
    if (userId == Api.I.userId) return E2E.I.myPublicB64;
    final c = _keys[userId];
    if (c != null) return c;
    try {
      final k = await Api.I.getKey(userId);
      _keys[userId] = k;
      return k;
    } catch (_) {
      return null;
    }
  }
}

/// نص قصير لعرضه في قائمة المحادثات (بيتفك التشفير محليًا)
Future<String> messagePreview(Map m, String convId) async {
  if (m['deleted'] == true) return '🚫 تم حذف الرسالة';
  switch (m['type']) {
    case 'snap':
      return '👻 Snap';
    case 'image':
      return '📷 صورة';
    case 'audio':
      return '🎤 رسالة صوتية';
    case 'file':
      return '📎 ملف';
  }
  final sender = m['sender_id'] as String;
  final pub = await KeyDirectory.I.key(sender);
  if (pub == null) return '🔒 رسالة مشفرة';
  final t = await E2E.I.decrypt(
    payload: m['ciphertext'] as String,
    convId: convId,
    senderId: sender,
    senderPubB64: pub,
  );
  if (t == null) return '🔒 رسالة مشفرة';
  if (m['type'] == 'reply') {
    try {
      return (jsonDecode(t)['text'] ?? '').toString();
    } catch (_) {
      return '↩️ رد';
    }
  }
  return t;
}
