import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../core/key_directory.dart';
import '../../core/push.dart';
import '../../core/socket.dart';
import '../auth/login_screen.dart';
import '../profile/profile_screen.dart';
import 'chat_screen.dart';
import 'group_screens.dart';

class ConversationsScreen extends StatefulWidget {
  const ConversationsScreen({super.key});
  @override
  State<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends State<ConversationsScreen> {
  late Future<List<dynamic>> _future = Api.I.conversations();
  StreamSubscription? _sub;
  Timer? _debounce;
  final Map<String, Future<String>> _previews = {}; // convId:msgId -> نص المعاينة

  @override
  void initState() {
    super.initState();
    // أي حدث بيغير القائمة (رسالة جديدة، قراءة، مسح، تغيير جروب) بيعمل تحديث
    _sub = ChatSocket.I.events.listen((e) {
      const t = {'message', 'read', 'deleted', 'conversation_updated', 'delivered'};
      if (t.contains(e['type'])) _scheduleReload();
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _debounce?.cancel();
    super.dispose();
  }

  void _scheduleReload() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      if (mounted) _reload();
    });
  }

  void _reload() => setState(() => _future = Api.I.conversations());

  Future<void> _open(Map c) async {
    final isGroup = c['type'] == 'group';
    final peer = c['peer'] as Map?;
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => ChatScreen(
                  conversationId: c['id'],
                  title: _title(c),
                  peerId: isGroup ? null : (peer?['id'] ?? '').toString(),
                  isGroup: isGroup,
                )));
    if (mounted) _reload();
  }

  String _title(Map c) {
    if (c['type'] == 'group') return ((c['name'] as String?) ?? '').isEmpty ? 'مجموعة' : c['name'];
    final peer = c['peer'] as Map?;
    final name = (peer?['name'] as String?) ?? '';
    return name.isNotEmpty ? name : (peer?['phone'] ?? 'مستخدم').toString();
  }

  Future<void> _newChat() async {
    final ctrl = TextEditingController();
    final phone = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('محادثة جديدة'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.phone,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(hintText: '+201000000000'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(c, ctrl.text.trim()),
              child: const Text('ابدأ')),
        ],
      ),
    );
    if (phone == null || phone.isEmpty) return;
    try {
      final u = await Api.I.lookup(phone);
      final id = await Api.I.openDirect(u['id']);
      final name = (u['name'] as String?) ?? '';
      if (!mounted) return;
      await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ChatScreen(
                  conversationId: id, title: name.isEmpty ? phone : name, peerId: u['id'])));
      if (mounted) _reload();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  Future<void> _newGroup() async {
    final r = await Navigator.push<Map>(
        context, MaterialPageRoute(builder: (_) => const NewGroupScreen()));
    if (r == null || !mounted) return;
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => ChatScreen(
                conversationId: r['id'], title: r['title'], isGroup: true)));
    if (mounted) _reload();
  }

  Future<void> _logout() async {
    ChatSocket.I.disconnect();
    await Push.unregister(); // لازم قبل الـ logout عشان لسه معانا توكن
    await Api.I.logout();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
        context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  String _time(String? iso) {
    final d = iso == null ? null : DateTime.tryParse(iso)?.toLocal();
    if (d == null) return '';
    final now = DateTime.now();
    if (d.year == now.year && d.month == now.month && d.day == now.day) {
      return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    }
    return '${d.day}/${d.month}';
  }

  Widget _preview(Map c) {
    final lm = c['last_message'] as Map?;
    if (lm == null) return const Text('ابدأ المحادثة');
    final key = '${c['id']}:${lm['id']}:${lm['deleted']}';
    final f = _previews.putIfAbsent(key, () => messagePreview(lm, c['id']));
    final mine = lm['sender_id'] == Api.I.userId;
    return FutureBuilder<String>(
      future: f,
      builder: (_, s) => Text(
        '${mine ? 'أنت: ' : ''}${s.data ?? '...'}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('المحادثات'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'group') _newGroup();
              if (v == 'profile') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
              }
              if (v == 'logout') _logout();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'group', child: Text('مجموعة جديدة')),
              PopupMenuItem(value: 'profile', child: Text('ملفي الشخصي')),
              PopupMenuItem(value: 'logout', child: Text('تسجيل الخروج')),
            ],
          ),
        ],
      ),
      floatingActionButton:
          FloatingActionButton(heroTag: 'chatFab', onPressed: _newChat, child: const Icon(Icons.edit)),
      body: FutureBuilder<List<dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة')));
          }
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('مفيش محادثات لسه'));
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final c = Map<String, dynamic>.from(list[i]);
                final title = _title(c);
                final unread = (c['unread'] as num?)?.toInt() ?? 0;
                final streak = (c['streak'] as num?)?.toInt() ?? 0;
                final lm = c['last_message'] as Map?;
                final isGroup = c['type'] == 'group';
                final online = (c['peer'] as Map?)?['online'] == true;
                return ListTile(
                  leading: Stack(children: [
                    CircleAvatar(
                        child: isGroup
                            ? const Icon(Icons.group)
                            : Text(title.characters.first.toUpperCase())),
                    if (online)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                              color: Colors.green,
                              shape: BoxShape.circle,
                              border: Border.all(color: cs.surface, width: 2)),
                        ),
                      ),
                  ]),
                  title: Row(children: [
                    Flexible(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis)),
                    if (streak > 0) Text('  🔥$streak', style: const TextStyle(fontSize: 13)),
                  ]),
                  subtitle: _preview(c),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(_time(lm?['created_at'] as String?),
                          style: TextStyle(
                              fontSize: 12, color: unread > 0 ? cs.primary : Colors.grey)),
                      if (unread > 0)
                        Container(
                          margin: const EdgeInsets.only(top: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration:
                              BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(10)),
                          child: Text('$unread',
                              style: TextStyle(color: cs.onPrimary, fontSize: 12)),
                        ),
                    ],
                  ),
                  onTap: () => _open(c),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
