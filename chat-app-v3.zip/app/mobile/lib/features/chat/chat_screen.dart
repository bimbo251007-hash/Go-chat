import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/api.dart';
import '../../core/crypto.dart';
import '../../core/key_directory.dart';
import '../../core/socket.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'group_screens.dart';
import 'audio_bubble.dart';
import 'media_bubble.dart';
import 'snap_bubble.dart';

class ChatScreen extends StatefulWidget {
  final String conversationId, title;
  final String? peerId; // null في الجروبات
  final bool isGroup;
  const ChatScreen({
    super.key,
    required this.conversationId,
    required this.title,
    this.peerId,
    this.isGroup = false,
  });
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final List<Map<String, dynamic>> _msgs = []; // الأحدث أولًا
  StreamSubscription? _sub;
  late final Future<void> _ready;
  bool _loading = true;
  bool _keyChanged = false;
  bool _removed = false; // اتشال من الجروب
  String? _fp, _error;
  int? _expireSec;
  late String _title = widget.title;

  /// userId -> {name, publicKey} لكل أعضاء المحادثة (ومنهم أنا)
  Map<String, Map<String, dynamic>> _members = {};
  List<String> _changedIds = [];

  // الكتابة والتواجد
  final Map<String, Timer> _typing = {};
  Timer? _typingIdle;
  DateTime _lastTypingSent = DateTime.fromMillisecondsSinceEpoch(0);
  Map<String, dynamic>? _presence;

  // تسجيل صوتي: اضغط المايك للبدء، ثم إرسال أو إلغاء
  final _rec = AudioRecorder();
  bool _recording = false;
  int _recSecs = 0;
  Timer? _recTimer;

  String get _me => Api.I.userId!;

  @override
  void initState() {
    super.initState();
    _sub = ChatSocket.I.events.listen(_onEvent);
    _input.addListener(_onTextChanged);
    _ready = _init();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _typingIdle?.cancel();
    _recTimer?.cancel();
    _rec.dispose();
    for (final t in _typing.values) {
      t.cancel();
    }
    _input.dispose();
    super.dispose();
  }

  // ---------- الأعضاء والمفاتيح ----------
  /// بيحمّل الأعضاء ومفاتيحهم ويتحقق (TOFU) إن مفتاح حد منهم ما اتغيرش
  Future<bool> _loadMembers() async {
    try {
      final m = <String, Map<String, dynamic>>{};
      if (widget.isGroup) {
        for (final u in await Api.I.members(widget.conversationId)) {
          final id = u['id'] as String;
          final name = (u['name'] as String?) ?? '';
          m[id] = {
            'name': name.isNotEmpty ? name : (u['phone'] ?? '').toString(),
            'publicKey': id == _me ? E2E.I.myPublicB64 : u['publicKey'],
            'role': u['role'],
          };
        }
      } else {
        final pub = await Api.I.getKey(widget.peerId!);
        m[widget.peerId!] = {'name': widget.title, 'publicKey': pub};
        m[_me] = {'name': 'أنا', 'publicKey': E2E.I.myPublicB64};
      }
      if (!m.containsKey(_me)) {
        _removed = true;
        _members = m;
        return false;
      }
      _removed = false;

      final missing = m.entries.where((e) => e.value['publicKey'] == null).toList();
      if (missing.isNotEmpty) {
        _error = 'فيه ${missing.length} عضو لسه ما فتحش التطبيق، مش هينفع تبعت لحد ما يفتحه.';
      } else {
        _error = null;
      }

      final changed = <String>[];
      for (final e in m.entries) {
        final pub = e.value['publicKey'] as String?;
        if (e.key == _me || pub == null) continue;
        KeyDirectory.I.put(e.key, pub);
        if (await E2E.I.checkPeer(e.key, pub) == KeyStatus.changed) changed.add(e.key);
      }
      _members = m;
      _changedIds = changed;
      _keyChanged = changed.isNotEmpty;
      if (!widget.isGroup) {
        _fp = await E2E.I.fingerprint(E2E.I.myPublicB64, m[widget.peerId!]!['publicKey'] as String);
      }
      return true;
    } catch (_) {
      _error = 'تعذر تجهيز التشفير. الطرف التاني لازم يفتح التطبيق مرة على الأقل.';
      return false;
    }
  }

  Future<void> _init() async {
    final ok = await _loadMembers();
    if (!widget.isGroup && widget.peerId != null) _loadPresence();
    if (!ok || _keyChanged) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    await _load();
  }

  Future<void> _loadPresence() async {
    try {
      final p = await Api.I.presence(widget.peerId!);
      if (mounted) setState(() => _presence = p);
    } catch (_) {}
  }

  bool get _canSend =>
      !_keyChanged && !_removed && _error == null && _members.isNotEmpty;

  Map<String, String> get _recipients => {
        for (final e in _members.entries) e.key: e.value['publicKey'] as String,
      };

  String _nameOf(String id) => (_members[id]?['name'] as String?) ?? 'عضو سابق';

  // ---------- تحميل وفك التشفير ----------
  Future<void> _decryptMsg(Map<String, dynamic> m) async {
    if (m['text'] != null || m['deleted'] == true) return;
    final sender = m['sender_id'] as String;
    final pub = (_members[sender]?['publicKey'] as String?) ?? await KeyDirectory.I.key(sender);
    if (pub == null) return;
    m['text'] = await E2E.I.decrypt(
      payload: m['ciphertext'],
      convId: widget.conversationId,
      senderId: sender,
      senderPubB64: sender == _me ? E2E.I.myPublicB64 : pub,
    );
  }

  Future<void> _load() async {
    try {
      final data = await Api.I.messages(widget.conversationId);
      final list = data.map((e) => Map<String, dynamic>.from(e)).toList();
      await Future.wait(list.map(_decryptMsg));
      if (!mounted) return;
      setState(() {
        _msgs
          ..clear()
          ..addAll(list);
        _loading = false;
      });
      if (list.any((m) => m['sender_id'] != _me && m['status'] != 'read')) {
        final newest = list.firstWhere((m) => m['sender_id'] != _me && m['status'] != 'read');
        _markRead(newest['id']);
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _markRead(String id) => ChatSocket.I.send({'type': 'read', 'messageId': id});

  // ---------- أحداث السوكت ----------
  Future<void> _onEvent(Map<String, dynamic> e) async {
    await _ready;
    if (!mounted) return;
    final type = e['type'];

    if (type == 'conversation_updated' && e['conversationId'] == widget.conversationId) {
      final ok = await _loadMembers();
      if (!mounted) return;
      setState(() {});
      if (ok && !_keyChanged && _msgs.isEmpty) await _load();
      return;
    }
    if (type == 'error' && e['error'] == 'members_changed' && e['conversationId'] == widget.conversationId) {
      // العضوية اتغيرت أثناء الإرسال: نحدّث الأعضاء ونعيد المحاولة مرة (للنصوص)
      final i = _msgs.indexWhere((m) => m['tempId'] == e['tempId']);
      await _loadMembers();
      if (!mounted) return;
      if (i != -1) {
        final m = _msgs[i];
        if (m['retried'] != true && m['type'] == null && m['plain'] != null && _canSend) {
          m['retried'] = true;
          await _sendEncrypted(m, m['plain'] as String);
        } else {
          setState(() => m['status'] = 'failed');
        }
      }
      setState(() {});
      return;
    }
    if (_keyChanged || _removed) return;

    if (type == 'message') {
      final m = Map<String, dynamic>.from(e['message']);
      if (m['conversation_id'] != widget.conversationId) return;
      if (!_members.containsKey(m['sender_id'])) await _loadMembers(); // عضو جديد
      await _decryptMsg(m);
      if (!mounted) return;
      setState(() => _msgs.insert(0, m));
      _markRead(m['id']);
      _typing.remove(m['sender_id'])?.cancel();
    } else if (type == 'ack') {
      final i = _msgs.indexWhere((m) => m['tempId'] == e['tempId']);
      if (i != -1) {
        setState(() {
          _msgs[i]['id'] = e['id'];
          _msgs[i]['status'] = e['status'] ?? 'sent';
        });
      }
    } else if (type == 'read' || type == 'delivered') {
      final i = _msgs.indexWhere((m) => m['id'] == e['messageId']);
      if (i != -1) {
        final cur = _msgs[i]['status'];
        if (type == 'read' || cur == 'sent') setState(() => _msgs[i]['status'] = type == 'read' ? 'read' : 'delivered');
        // "اتقرأت" بتغطي كل اللي قبلها
        if (type == 'read') {
          setState(() {
            for (var j = i; j < _msgs.length; j++) {
              if (_msgs[j]['sender_id'] == _me && _msgs[j]['status'] != 'sending') _msgs[j]['status'] = 'read';
            }
          });
        }
      }
    } else if (type == 'deleted') {
      final i = _msgs.indexWhere((m) => m['id'] == e['messageId']);
      if (i != -1) {
        setState(() {
          _msgs[i]
            ..['deleted'] = true
            ..['text'] = null
            ..['media_id'] = null
            ..['bytes'] = null;
        });
      }
    } else if (type == 'snap_opened') {
      final i = _msgs.indexWhere((m) => m['id'] == e['messageId']);
      if (i != -1) setState(() => _msgs[i]['snap_viewed'] = true);
    } else if (type == 'screenshot') {
      if (e['conversationId'] == widget.conversationId) {
        _snack('📸 ${_nameOf(e['userId'] as String)} صوّر الـ Snap');
      }
    } else if (type == 'typing' && e['conversationId'] == widget.conversationId) {
      final uid = e['userId'] as String;
      _typing.remove(uid)?.cancel();
      if (e['typing'] == true) {
        _typing[uid] = Timer(const Duration(seconds: 5), () {
          _typing.remove(uid);
          if (mounted) setState(() {});
        });
      }
      setState(() {});
    }
  }

  // ---------- الإرسال ----------
  void _onTextChanged() {
    if (_input.text.isEmpty || !_canSend) return;
    final now = DateTime.now();
    if (now.difference(_lastTypingSent).inSeconds >= 3) {
      _lastTypingSent = now;
      ChatSocket.I.send({'type': 'typing', 'conversationId': widget.conversationId, 'typing': true});
    }
    _typingIdle?.cancel();
    _typingIdle = Timer(const Duration(seconds: 4), _stopTyping);
  }

  void _stopTyping() {
    _lastTypingSent = DateTime.fromMillisecondsSinceEpoch(0);
    ChatSocket.I.send({'type': 'typing', 'conversationId': widget.conversationId, 'typing': false});
  }

  Future<void> _sendEncrypted(Map<String, dynamic> m, String plain) async {
    final payload = await E2E.I.encrypt(
      plaintext: plain,
      recipients: _recipients,
      convId: widget.conversationId,
    );
    final ok = ChatSocket.I.send({
      'type': 'send',
      'conversationId': widget.conversationId,
      'ciphertext': payload,
      'tempId': m['tempId'],
      if (_expireSec != null) 'expiresInSec': _expireSec,
    });
    if (!ok && mounted) setState(() => m['status'] = 'failed');
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || !_canSend) return;
    _input.clear();
    _typingIdle?.cancel();
    _stopTyping();
    final m = <String, dynamic>{
      'tempId': DateTime.now().microsecondsSinceEpoch.toString(),
      'sender_id': _me,
      'text': text,
      'plain': text,
      'status': 'sending',
    };
    setState(() => _msgs.insert(0, m));
    await _sendEncrypted(m, text);
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _sendMedia(Uint8List bytes, String name, String mime, String type,
      {Map<String, dynamic>? extra}) async {
    if (!_canSend) return;
    if (bytes.length > 10 * 1024 * 1024) return _snack('الحد الأقصى للملف 10 ميجا');
    final m = <String, dynamic>{
      'tempId': DateTime.now().microsecondsSinceEpoch.toString(),
      'sender_id': _me,
      'type': type,
      'bytes': type == 'snap' ? null : bytes, // الـ Snap مش بنعرضه عند المرسل
      'text': null,
      'status': 'sending',
    };
    setState(() => _msgs.insert(0, m));
    try {
      final enc = await E2E.I.encryptBlob(bytes);
      final meta = jsonEncode(
          {'key': enc.key, 'name': name, 'mime': mime, 'size': bytes.length, ...?extra});
      final id = await Api.I.uploadBlob(enc.blob);
      final payload = await E2E.I.encrypt(
        plaintext: meta,
        recipients: _recipients,
        convId: widget.conversationId,
      );
      if (!mounted) return;
      setState(() {
        m['text'] = meta;
        m['media_id'] = id;
      });
      final ok = ChatSocket.I.send({
        'type': 'send',
        'conversationId': widget.conversationId,
        'ciphertext': payload,
        'msgType': type,
        'mediaId': id,
        'tempId': m['tempId'],
        if (_expireSec != null && type != 'snap') 'expiresInSec': _expireSec,
      });
      if (!ok && mounted) setState(() => m['status'] = 'failed');
    } catch (_) {
      if (mounted) setState(() => m['status'] = 'failed');
    }
  }

  Future<void> _startRecording() async {
    if (!_canSend) return;
    try {
      if (!await _rec.hasPermission()) return _snack('محتاج إذن المايك');
      final dir = await getTemporaryDirectory();
      await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc),
          path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a');
      setState(() {
        _recording = true;
        _recSecs = 0;
      });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recSecs++);
        if (_recSecs >= 300) _finishRecording(send: true); // حد أقصى 5 دقايق
      });
    } catch (_) {
      if (mounted) _snack('تعذر بدء التسجيل');
    }
  }

  Future<void> _finishRecording({required bool send}) async {
    if (!_recording) return;
    _recTimer?.cancel();
    final secs = _recSecs;
    setState(() => _recording = false);
    try {
      final path = await _rec.stop();
      if (path == null) return;
      final f = File(path);
      final bytes = await f.readAsBytes();
      await f.delete().catchError((_) => f); // مفيش نسخة صوت بتفضل على الجهاز
      if (send && secs >= 1) {
        await _sendMedia(bytes, 'voice.m4a', 'audio/mp4', 'audio', extra: {'seconds': secs});
      }
    } catch (_) {
      if (mounted) _snack('تعذر حفظ التسجيل');
    }
  }

  Future<void> _sendSnap() async {
    final secs = await showModalBottomSheet<int>(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          const Padding(
              padding: EdgeInsets.all(16),
              child: Text('مدة عرض الـ Snap', style: TextStyle(fontWeight: FontWeight.bold))),
          for (final s in [3, 5, 10, 15])
            ListTile(
                leading: const Icon(Icons.timer_outlined),
                title: Text('$s ثواني'),
                onTap: () => Navigator.pop(c, s)),
        ]),
      ),
    );
    if (secs == null) return;
    try {
      final x = await ImagePicker().pickImage(
          source: ImageSource.camera, maxWidth: 1920, imageQuality: 85);
      if (x == null) return;
      await _sendMedia(await x.readAsBytes(), 'snap.jpg', 'image/jpeg', 'snap',
          extra: {'seconds': secs});
    } catch (_) {
      if (mounted) _snack('تعذر فتح الكاميرا');
    }
  }

  Future<void> _pickAttachment() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          ListTile(
              leading: const Icon(Icons.square, color: Colors.redAccent),
              title: const Text('Snap (بيتفتح مرة واحدة)'),
              onTap: () => Navigator.pop(c, 'snap')),
          ListTile(
              leading: const Icon(Icons.photo),
              title: const Text('صورة من المعرض'),
              onTap: () => Navigator.pop(c, 'gallery')),
          ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('الكاميرا'),
              onTap: () => Navigator.pop(c, 'camera')),
          ListTile(
              leading: const Icon(Icons.insert_drive_file),
              title: const Text('ملف'),
              onTap: () => Navigator.pop(c, 'file')),
        ]),
      ),
    );
    if (choice == null) return;
    if (choice == 'snap') return _sendSnap();
    try {
      if (choice == 'file') {
        final r = await FilePicker.platform.pickFiles(withData: true);
        final f = r?.files.single;
        if (f == null || f.bytes == null) return;
        await _sendMedia(f.bytes!, f.name, 'application/octet-stream', 'file');
      } else {
        final x = await ImagePicker().pickImage(
          source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery,
          maxWidth: 1920,
          imageQuality: 85,
        );
        if (x == null) return;
        await _sendMedia(await x.readAsBytes(), x.name, 'image/jpeg', 'image');
      }
    } catch (_) {
      if (mounted) _snack('تعذر اختيار الملف');
    }
  }

  // ---------- مسح ونسخ ----------
  Future<void> _messageMenu(Map<String, dynamic> m) async {
    if (m['deleted'] == true || m['id'] == null) return;
    final mine = m['sender_id'] == _me;
    final isText = m['type'] == null && m['text'] != null;
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          if (isText)
            ListTile(
                leading: const Icon(Icons.copy),
                title: const Text('نسخ'),
                onTap: () => Navigator.pop(c, 'copy')),
          ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('مسح عندي'),
              onTap: () => Navigator.pop(c, 'me')),
          if (mine)
            ListTile(
                leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
                title: const Text('مسح للجميع'),
                onTap: () => Navigator.pop(c, 'all')),
        ]),
      ),
    );
    if (choice == null) return;
    if (choice == 'copy') {
      await Clipboard.setData(ClipboardData(text: m['text'] as String));
      return;
    }
    try {
      await Api.I.deleteMessage(m['id'] as String, forEveryone: choice == 'all');
      if (!mounted) return;
      setState(() {
        if (choice == 'me') {
          _msgs.remove(m);
        } else {
          m
            ..['deleted'] = true
            ..['text'] = null
            ..['media_id'] = null
            ..['bytes'] = null;
        }
      });
    } catch (e) {
      if (mounted) _snack(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _acceptKey() async {
    for (final id in _changedIds) {
      await E2E.I.acceptPeer(id, _members[id]!['publicKey'] as String);
    }
    setState(() {
      _keyChanged = false;
      _changedIds = [];
      _loading = true;
    });
    await _load();
  }

  void _showFingerprint() => showDialog(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('رقم الأمان'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_fp ?? '—',
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, letterSpacing: 1.5, fontFamily: 'monospace')),
            const SizedBox(height: 12),
            const Text('قارن الرقم ده مع صاحبك (وجهًا لوجه أو بمكالمة). لو متطابق، '
                'يبقى مفيش حد بينكم بيتجسس على المحادثة.'),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('تمام'))],
        ),
      );

  Future<void> _openGroupInfo() async {
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => GroupInfoScreen(conversationId: widget.conversationId, title: _title)));
    if (!mounted) return;
    try {
      // الاسم ممكن يكون اتغير
      final list = await Api.I.conversations();
      final me = list.firstWhere((c) => c['id'] == widget.conversationId, orElse: () => null);
      final n = me?['name'] as String?;
      if (n != null && n.isNotEmpty) _title = n;
    } catch (_) {}
    await _loadMembers();
    if (mounted) setState(() {});
  }

  // رد على حالة: اقتباس صغير + نص الرد
  Widget _replyBubble(Map<String, dynamic> m, Color fg) {
    try {
      final j = jsonDecode(m['text'] as String) as Map<String, dynamic>;
      final q = j['quote'] as Map<String, dynamic>?;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (q != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: fg.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border(right: BorderSide(color: fg, width: 3)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('رد على الحالة',
                    style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.bold)),
                Text((q['preview'] ?? '').toString(),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: fg.withOpacity(0.85), fontSize: 13)),
              ]),
            ),
          Text((j['text'] ?? '').toString(), style: TextStyle(color: fg)),
        ],
      );
    } catch (_) {
      return Text('🔒 تعذر فك التشفير', style: TextStyle(color: fg));
    }
  }

  Widget _tick(String? s) {
    switch (s) {
      case 'read':
        return const Icon(Icons.done_all, size: 14, color: Colors.lightBlueAccent);
      case 'delivered':
        return const Icon(Icons.done_all, size: 14, color: Colors.white70);
      case 'sent':
        return const Icon(Icons.done, size: 14, color: Colors.white70);
      case 'failed':
        return const Icon(Icons.error_outline, size: 14, color: Colors.redAccent);
      default:
        return const Icon(Icons.access_time, size: 14, color: Colors.white70);
    }
  }

  String _hm(String iso) {
    final d = DateTime.tryParse(iso)?.toLocal();
    if (d == null) return '';
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  String? get _subtitle {
    if (_typing.isNotEmpty) {
      if (!widget.isGroup) return 'بيكتب...';
      final names = _typing.keys.map(_nameOf).toList();
      return names.length == 1 ? '${names.first} بيكتب...' : 'كذا حد بيكتب...';
    }
    if (widget.isGroup) return _members.isEmpty ? null : '${_members.length} عضو';
    final p = _presence;
    if (p == null) return null;
    if (p['online'] == true) return 'متصل الآن';
    final ls = p['lastSeen'] as String?;
    return ls == null ? null : 'آخر ظهور ${_hm(ls)}';
  }

  Widget _body(Map<String, dynamic> m, bool mine, ColorScheme cs) {
    final fg = mine ? cs.onPrimary : cs.onSurface;
    if (m['deleted'] == true) {
      return Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.block, size: 16, color: fg.withOpacity(0.6)),
        const SizedBox(width: 6),
        Text('تم حذف الرسالة',
            style: TextStyle(color: fg.withOpacity(0.6), fontStyle: FontStyle.italic)),
      ]);
    }
    switch (m['type']) {
      case 'image':
      case 'file':
        return MediaBubble(msg: m, fg: fg);
      case 'audio':
        return AudioBubble(msg: m, fg: fg);
      case 'snap':
        return SnapBubble(msg: m, mine: mine, fg: fg);
      case 'reply':
        return _replyBubble(m, fg);
    }
    return Text(m['text'] ?? '🔒 تعذر فك التشفير', style: TextStyle(color: fg));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final sub = _subtitle;
    return Scaffold(
      appBar: AppBar(
        title: InkWell(
          onTap: widget.isGroup && !_removed ? _openGroupInfo : null,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_title),
            if (sub != null)
              Text(sub,
                  style: TextStyle(
                      fontSize: 12,
                      color: _typing.isNotEmpty ? cs.primary : cs.onSurface.withOpacity(0.6))),
          ]),
        ),
        actions: [
          if (!widget.isGroup)
            IconButton(
                icon: const Icon(Icons.verified_user_outlined),
                tooltip: 'رقم الأمان',
                onPressed: _fp == null ? null : _showFingerprint),
          PopupMenuButton<int>(
            icon: Icon(_expireSec == null ? Icons.timer_off_outlined : Icons.timer),
            tooltip: 'رسائل مؤقتة',
            onSelected: (v) => setState(() => _expireSec = v == 0 ? null : v),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 0, child: Text('إيقاف')),
              PopupMenuItem(value: 60, child: Text('بعد دقيقة')),
              PopupMenuItem(value: 3600, child: Text('بعد ساعة')),
              PopupMenuItem(value: 86400, child: Text('بعد 24 ساعة')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        if (_keyChanged)
          MaterialBanner(
            backgroundColor: cs.errorContainer,
            content: Text(widget.isGroup
                ? '⚠️ رقم الأمان لـ ${_changedIds.map(_nameOf).join('، ')} اتغير. ممكن يكون غيّر جهازه، '
                    'أو حد بيحاول يتجسس. تأكد منه قبل ما توافق.'
                : '⚠️ رقم الأمان لصاحبك اتغير. ممكن يكون غيّر جهازه، أو حد بيحاول يتجسس. '
                    'تأكد منه قبل ما توافق.'),
            actions: [TextButton(onPressed: _acceptKey, child: const Text('أوافق على المفتاح الجديد'))],
          ),
        if (_removed)
          Container(
              width: double.infinity,
              color: cs.errorContainer,
              padding: const EdgeInsets.all(12),
              child: const Text('مبقتش عضو في الجروب ده.')),
        if (_error != null && !_removed)
          Container(
              width: double.infinity,
              color: cs.errorContainer,
              padding: const EdgeInsets.all(12),
              child: Text(_error!)),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: _msgs.length,
                  itemBuilder: (_, i) {
                    final m = _msgs[i];
                    final mine = m['sender_id'] == _me;
                    final showName = widget.isGroup && !mine;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: GestureDetector(
                        onLongPress: () => _messageMenu(m),
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 3),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          constraints:
                              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                          decoration: BoxDecoration(
                            color: mine ? cs.primary : cs.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            if (showName)
                              Align(
                                alignment: Alignment.centerRight,
                                child: Text(_nameOf(m['sender_id'] as String),
                                    style: TextStyle(
                                        color: cs.primary, fontSize: 12, fontWeight: FontWeight.bold)),
                              ),
                            _body(m, mine, cs),
                            if (mine && m['deleted'] != true) _tick(m['status']),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: _recording
                ? Row(children: [
                    IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                        onPressed: () => _finishRecording(send: false)),
                    const Icon(Icons.fiber_manual_record, color: Colors.red, size: 14),
                    const SizedBox(width: 6),
                    Text('${_recSecs ~/ 60}:${(_recSecs % 60).toString().padLeft(2, '0')}'),
                    const Spacer(),
                    IconButton.filled(
                        onPressed: () => _finishRecording(send: true), icon: const Icon(Icons.send)),
                  ])
                : Row(children: [
              IconButton(
                  onPressed: _canSend ? _pickAttachment : null,
                  icon: const Icon(Icons.attach_file)),
              Expanded(
                child: TextField(
                  controller: _input,
                  enabled: _canSend,
                  minLines: 1,
                  maxLines: 4,
                  onChanged: (_) => setState(() {}),
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(
                    hintText: 'اكتب رسالة...',
                    filled: true,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              _input.text.trim().isEmpty
                  ? IconButton.filled(
                      onPressed: _canSend ? _startRecording : null, icon: const Icon(Icons.mic))
                  : IconButton.filled(onPressed: _canSend ? _send : null, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
