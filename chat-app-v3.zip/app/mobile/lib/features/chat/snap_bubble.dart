import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../core/crypto.dart';

/// Snap: صورة بتتفتح مرة واحدة بس. السيرفر هو اللي بيفرض كده:
/// أول تحميل للمستلم = "فتح"، وبعدها الملف بيتمسح من السيرفر.
class SnapBubble extends StatefulWidget {
  final Map<String, dynamic> msg;
  final bool mine;
  final Color fg;
  const SnapBubble({super.key, required this.msg, required this.mine, required this.fg});
  @override
  State<SnapBubble> createState() => _SnapBubbleState();
}

class _SnapBubbleState extends State<SnapBubble> {
  bool _busy = false;
  String? _error;

  bool get _viewed => widget.msg['snap_viewed'] == true;

  Map<String, dynamic>? get _meta {
    try {
      final t = widget.msg['text'];
      return t == null ? null : jsonDecode(t as String) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<void> _open() async {
    final meta = _meta;
    final id = widget.msg['media_id'];
    if (meta == null || id == null || _busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final blob = await Api.I.downloadBlob(id as String);
      // من هنا السيرفر اعتبرها اتفتحت
      widget.msg['snap_viewed'] = true;
      final clear = await E2E.I.decryptBlob(blob, meta['key'] as String);
      if (clear == null) throw Exception('الـ Snap تالف');
      final secs = ((meta['seconds'] as num?)?.toInt() ?? 8).clamp(1, 30).toInt();
      if (!mounted) return;
      await Navigator.push(
          context, MaterialPageRoute(builder: (_) => SnapViewer(bytes: clear, seconds: secs)));
    } catch (e) {
      // 404 = اتفتح قبل كده أو انتهى
      widget.msg['snap_viewed'] = true;
      _error = 'الـ Snap اتفتح أو انتهى';
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final fg = widget.fg;
    if (widget.mine) {
      return Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(_viewed ? Icons.crop_square : Icons.square, color: fg, size: 18),
        const SizedBox(width: 6),
        Text(_viewed ? 'Snap اتفتح' : 'Snap اتبعت', style: TextStyle(color: fg)),
      ]);
    }
    if (_viewed) {
      return Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.crop_square, color: fg.withOpacity(0.6), size: 18),
        const SizedBox(width: 6),
        Text(_error ?? 'Snap اتفتح', style: TextStyle(color: fg.withOpacity(0.6))),
      ]);
    }
    return InkWell(
      onTap: _busy ? null : _open,
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        _busy
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
            : Icon(Icons.square, color: Colors.redAccent, size: 18),
        const SizedBox(width: 6),
        Text('اضغط لفتح الـ Snap', style: TextStyle(color: fg, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

class SnapViewer extends StatefulWidget {
  final Uint8List bytes;
  final int seconds;
  const SnapViewer({super.key, required this.bytes, required this.seconds});
  @override
  State<SnapViewer> createState() => _SnapViewerState();
}

class _SnapViewerState extends State<SnapViewer> {
  late int _left = widget.seconds;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_left <= 1) {
        t.cancel();
        if (mounted) Navigator.pop(context);
      } else {
        setState(() => _left--);
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Stack(fit: StackFit.expand, children: [
          Center(child: Image.memory(widget.bytes, fit: BoxFit.contain)),
          SafeArea(
            child: Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: CircleAvatar(
                  backgroundColor: Colors.black54,
                  child: Text('$_left', style: const TextStyle(color: Colors.white)),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
