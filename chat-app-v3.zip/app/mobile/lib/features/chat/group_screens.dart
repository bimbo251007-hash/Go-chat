import 'package:flutter/material.dart';
import '../../core/api.dart';

String _label(dynamic c) {
  final n = (c['name'] as String?) ?? '';
  return n.isNotEmpty ? n : (c['phone'] ?? '').toString();
}

void _toast(BuildContext context, Object e) => ScaffoldMessenger.of(context)
    .showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));

/// اختيار أعضاء من جهات الاتصال (اللي بينك وبينهم محادثة فردية)
Future<List<String>?> pickContacts(BuildContext context,
    {Set<String> exclude = const {}, String title = 'اختار الأعضاء'}) {
  return Navigator.push<List<String>>(
      context, MaterialPageRoute(builder: (_) => _ContactPicker(exclude: exclude, title: title)));
}

class _ContactPicker extends StatefulWidget {
  final Set<String> exclude;
  final String title;
  const _ContactPicker({required this.exclude, required this.title});
  @override
  State<_ContactPicker> createState() => _ContactPickerState();
}

class _ContactPickerState extends State<_ContactPicker> {
  List<dynamic> _contacts = [];
  final Set<String> _sel = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    Api.I.storyContacts().then((r) {
      if (!mounted) return;
      setState(() {
        _contacts = r.where((c) => !widget.exclude.contains(c['id'])).toList();
        _loading = false;
      });
    }).catchError((_) {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [
        TextButton(
            onPressed: _sel.isEmpty ? null : () => Navigator.pop(context, _sel.toList()),
            child: const Text('تم')),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _contacts.isEmpty
              ? const Center(child: Text('مفيش جهات اتصال متاحة. ابدأ محادثة فردية الأول.'))
              : ListView(children: [
                  for (final c in _contacts)
                    CheckboxListTile(
                      value: _sel.contains(c['id']),
                      onChanged: (v) => setState(() {
                        v == true ? _sel.add(c['id']) : _sel.remove(c['id']);
                      }),
                      title: Text(_label(c)),
                    ),
                ]),
    );
  }
}

/// إنشاء جروب جديد. بيرجّع {id, title} لما ينجح.
class NewGroupScreen extends StatefulWidget {
  const NewGroupScreen({super.key});
  @override
  State<NewGroupScreen> createState() => _NewGroupScreenState();
}

class _NewGroupScreenState extends State<NewGroupScreen> {
  final _name = TextEditingController();
  List<dynamic> _contacts = [];
  final Set<String> _sel = {};
  bool _loading = true, _saving = false;

  @override
  void initState() {
    super.initState();
    Api.I.storyContacts().then((r) {
      if (!mounted) return;
      setState(() {
        _contacts = r;
        _loading = false;
      });
    }).catchError((_) {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final name = _name.text.trim();
    if (name.isEmpty || _sel.isEmpty) return;
    setState(() => _saving = true);
    try {
      final id = await Api.I.createGroup(name, _sel.toList());
      if (mounted) Navigator.pop(context, {'id': id, 'title': name});
    } catch (e) {
      if (mounted) {
        _toast(context, e);
        setState(() => _saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مجموعة جديدة')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  controller: _name,
                  maxLength: 60,
                  decoration: const InputDecoration(
                      labelText: 'اسم المجموعة', border: OutlineInputBorder()),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              if (_contacts.isEmpty)
                const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('مفيش جهات اتصال لسه. ابدأ محادثة فردية مع حد الأول.')),
              for (final c in _contacts)
                CheckboxListTile(
                  value: _sel.contains(c['id']),
                  onChanged: (v) => setState(() {
                    v == true ? _sel.add(c['id']) : _sel.remove(c['id']);
                  }),
                  title: Text(_label(c)),
                ),
            ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton(
            onPressed: (_saving || _name.text.trim().isEmpty || _sel.isEmpty) ? null : _create,
            child: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : Text('إنشاء (${_sel.length})'),
          ),
        ),
      ),
    );
  }
}

/// معلومات الجروب: الأعضاء، إضافة/إزالة (للمشرفين)، تغيير الاسم، مغادرة.
class GroupInfoScreen extends StatefulWidget {
  final String conversationId, title;
  const GroupInfoScreen({super.key, required this.conversationId, required this.title});
  @override
  State<GroupInfoScreen> createState() => _GroupInfoScreenState();
}

class _GroupInfoScreenState extends State<GroupInfoScreen> {
  List<dynamic> _members = [];
  late String _title = widget.title;
  bool _loading = true;

  String get _me => Api.I.userId!;
  bool get _admin => _members.any((m) => m['id'] == _me && m['role'] == 'admin');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Api.I.members(widget.conversationId);
      if (mounted) setState(() => _members = r);
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _run(Future<void> Function() fn) async {
    try {
      await fn();
      await _load();
    } catch (e) {
      if (mounted) _toast(context, e);
    }
  }

  Future<void> _rename() async {
    final ctrl = TextEditingController(text: _title);
    final name = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('اسم المجموعة'),
        content: TextField(controller: ctrl, maxLength: 60),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    if (name == null || name.isEmpty || name == _title) return;
    await _run(() async {
      await Api.I.renameGroup(widget.conversationId, name);
      setState(() => _title = name);
    });
  }

  Future<void> _add() async {
    final ids = await pickContacts(context,
        exclude: _members.map((m) => m['id'] as String).toSet(), title: 'إضافة أعضاء');
    if (ids == null || ids.isEmpty) return;
    await _run(() => Api.I.addMembers(widget.conversationId, ids));
  }

  Future<void> _leave() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('مغادرة المجموعة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('غادر')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.I.removeMember(widget.conversationId, _me);
      if (mounted) Navigator.popUntil(context, (r) => r.isFirst);
    } catch (e) {
      if (mounted) _toast(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text(_title), actions: [
          if (_admin) IconButton(icon: const Icon(Icons.edit), onPressed: _rename),
        ]),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text('${_members.length} عضو',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
                if (_admin)
                  ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person_add)),
                    title: const Text('إضافة أعضاء'),
                    onTap: _add,
                  ),
                for (final m in _members)
                  ListTile(
                    leading: CircleAvatar(
                        child: Text(_label(m).characters.first.toUpperCase())),
                    title: Text(m['id'] == _me ? 'أنت' : _label(m)),
                    subtitle: m['role'] == 'admin' ? const Text('مشرف') : null,
                    trailing: (_admin && m['id'] != _me)
                        ? PopupMenuButton<String>(
                            onSelected: (v) => _run(() => v == 'remove'
                                ? Api.I.removeMember(widget.conversationId, m['id'])
                                : Api.I.setRole(widget.conversationId, m['id'],
                                    m['role'] == 'admin' ? 'member' : 'admin')),
                            itemBuilder: (_) => [
                              PopupMenuItem(
                                  value: 'role',
                                  child: Text(m['role'] == 'admin' ? 'شيل الإشراف' : 'خليه مشرف')),
                              const PopupMenuItem(value: 'remove', child: Text('إزالة من المجموعة')),
                            ],
                          )
                        : null,
                  ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.exit_to_app, color: Colors.redAccent),
                  title: const Text('مغادرة المجموعة', style: TextStyle(color: Colors.redAccent)),
                  onTap: _leave,
                ),
              ]),
    );
  }
}
