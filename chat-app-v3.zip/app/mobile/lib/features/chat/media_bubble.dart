import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import '../../core/api.dart';
import '../../core/crypto.dart';

/// بيعرض صورة أو ملف: بينزّل الـ Blob المشفر، يتأكد إنه سليم، ويفكه محليًا.
class MediaBubble extends StatefulWidget {
  final Map<String, dynamic> msg;
  final Color fg;
  const MediaBubble({super.key, required this.msg, required this.fg});
  @override
  State<MediaBubble> createState() => _MediaBubbleState();
}

class _MediaBubbleState extends State<MediaBubble> {
  bool _loading = false;
  String? _error;

  bool get _isImage => widget.msg['type'] == 'image';
  Uint8List? get _bytes => widget.msg['bytes'] as Uint8List?;

  Map<String, dynamic>? get _meta {
    try {
      final t = widget.msg['text'];
      return t == null ? null : jsonDecode(t as String) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    if (_isImage && _bytes == null) _fetch();
  }

  Future<Uint8List> _download() async {
    final meta = _meta;
    final id = widget.msg['media_id'];
    if (meta == null || id == null) throw Exception('بيانات الملف ناقصة');
    final blob = await Api.I.downloadBlob(id as String);
    final clear = await E2E.I.decryptBlob(blob, meta['key'] as String);
    if (clear == null) throw Exception('الملف تالف أو اتعدّل');
    widget.msg['bytes'] = clear; // كاش في الذاكرة
    return clear;
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      await _download();
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => _loading = false);
  }

  // اسم الملف جاي من المرسل: نشيل أي مسارات أو رموز غريبة
  String _safeName(String n) {
    final base = n.split(RegExp(r'[\\/]')).last;
    final c = base.replaceAll(RegExp(r'[^\w\.\- ]'), '_');
    if (c.isEmpty) return 'file';
    return c.length > 80 ? c.substring(c.length - 80) : c;
  }

  String _fmt(int b) =>
      b < 1024 * 1024 ? '${(b / 1024).toStringAsFixed(0)} ك.ب' : '${(b / 1048576).toStringAsFixed(1)} م.ب';

  Future<void> _openFile() async {
    setState(() => _loading = true);
    try {
      final bytes = _bytes ?? await _download();
      final dir = await getTemporaryDirectory();
      final name = _safeName((_meta?['name'] ?? 'file') as String);
      final f = File('${dir.path}/${DateTime.now().millisecondsSinceEpoch}_$name');
      await f.writeAsBytes(bytes, flush: true);
      await OpenFilex.open(f.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceFirst('Exception: ', ''))));
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  void _viewFull() => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
            body: Center(child: InteractiveViewer(child: Image.memory(_bytes!))),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_isImage) {
      if (_bytes != null) {
        return GestureDetector(
          onTap: _viewFull,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.memory(_bytes!,
                width: 220,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Icon(Icons.broken_image, color: widget.fg, size: 48)),
          ),
        );
      }
      if (_error != null) {
        return Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.lock_outline, color: widget.fg, size: 18),
          const SizedBox(width: 6),
          Flexible(child: Text(_error!, style: TextStyle(color: widget.fg))),
        ]);
      }
      return const SizedBox(width: 220, height: 140, child: Center(child: CircularProgressIndicator()));
    }

    final meta = _meta;
    final name = (meta?['name'] ?? 'ملف') as String;
    final size = meta?['size'] as int?;
    return InkWell(
      onTap: _loading ? null : _openFile,
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.insert_drive_file, color: widget.fg),
        const SizedBox(width: 8),
        Flexible(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: widget.fg)),
            if (size != null)
              Text(_fmt(size), style: TextStyle(color: widget.fg.withOpacity(0.7), fontSize: 12)),
          ]),
        ),
        if (_loading)
          const Padding(
              padding: EdgeInsets.only(right: 8),
              child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))),
      ]),
    );
  }
}
