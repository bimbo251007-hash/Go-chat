import 'dart:convert';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../core/crypto.dart';

/// رسالة صوتية: بتتنزّل مشفرة، تتفك محليًا، وتتشغّل من الذاكرة.
class AudioBubble extends StatefulWidget {
  final Map<String, dynamic> msg;
  final Color fg;
  const AudioBubble({super.key, required this.msg, required this.fg});
  @override
  State<AudioBubble> createState() => _AudioBubbleState();
}

class _AudioBubbleState extends State<AudioBubble> {
  final _player = AudioPlayer();
  bool _playing = false, _loading = false;
  Duration _pos = Duration.zero;
  String? _error;

  Map<String, dynamic>? get _meta {
    try {
      final t = widget.msg['text'];
      return t == null ? null : jsonDecode(t as String) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  int get _secs => ((_meta?['seconds'] as num?)?.toInt() ?? 0);

  @override
  void initState() {
    super.initState();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() { _playing = false; _pos = Duration.zero; });
    });
    _player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _pos = p);
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<Uint8List> _bytes() async {
    final cached = widget.msg['bytes'] as Uint8List?;
    if (cached != null) return cached;
    final meta = _meta;
    final id = widget.msg['media_id'];
    if (meta == null || id == null) throw Exception('بيانات الصوت ناقصة');
    final blob = await Api.I.downloadBlob(id as String);
    final clear = await E2E.I.decryptBlob(blob, meta['key'] as String);
    if (clear == null) throw Exception('الملف تالف أو اتعدّل');
    return widget.msg['bytes'] = clear;
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _player.pause();
      setState(() => _playing = false);
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      final b = await _bytes();
      await _player.play(BytesSource(b));
      _playing = true;
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => _loading = false);
  }

  String _fmt(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final fg = widget.fg;
    final total = _secs;
    final progress = total == 0 ? 0.0 : (_pos.inMilliseconds / (total * 1000)).clamp(0.0, 1.0).toDouble();
    return SizedBox(
      width: 200,
      child: Row(children: [
        _loading
            ? const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 2))
            : IconButton(
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle, color: fg, size: 32),
                onPressed: _toggle),
        const SizedBox(width: 8),
        Expanded(
          child: _error != null
              ? Text(_error!, style: TextStyle(color: fg, fontSize: 12))
              : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  LinearProgressIndicator(value: progress, color: fg, backgroundColor: fg.withOpacity(0.25)),
                  const SizedBox(height: 4),
                  Text(_playing ? _fmt(_pos.inSeconds) : _fmt(total),
                      style: TextStyle(color: fg.withOpacity(0.8), fontSize: 11)),
                ]),
        ),
      ]),
    );
  }
}
