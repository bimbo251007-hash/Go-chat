import 'package:flutter/material.dart';
import '../../core/api.dart';
import 'status_style.dart';
import 'story_actions.dart';

class StoryViewerScreen extends StatefulWidget {
  final List<Map<String, dynamic>> stories; // لنفس الشخص، من الأقدم للأحدث
  final String authorName;
  final bool mine;
  const StoryViewerScreen({
    super.key,
    required this.stories,
    required this.authorName,
    required this.mine,
  });
  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 5));
  final _reply = TextEditingController();
  final _focus = FocusNode();
  int _i = 0;
  StoryContent? _content;
  String? _error;
  List<dynamic> _viewers = [];

  @override
  void initState() {
    super.initState();
    // نبدأ من أول حالة لسه ماتشافتش
    final firstNew = widget.stories.indexWhere((s) => s['viewed'] != true);
    if (!widget.mine && firstNew > 0) _i = firstNew;
    _c.addStatusListener((s) {
      if (s == AnimationStatus.completed) _next();
    });
    _focus.addListener(() {
      if (_focus.hasFocus) {
        _c.stop();
      } else if (_content != null) {
        _c.forward();
      }
    });
    _show();
  }

  @override
  void dispose() {
    _c.dispose();
    _reply.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _show() async {
    _c.stop();
    _c.value = 0;
    setState(() {
      _content = null;
      _error = null;
      _viewers = [];
    });
    final s = widget.stories[_i];
    try {
      final c = await openStory(s);
      if (!mounted || widget.stories[_i] != s) return;
      setState(() => _content = c);
      if (!_focus.hasFocus) _c.forward();
      if (widget.mine) {
        _loadViewers(s['id']);
      } else {
        Api.I.viewStory(s['id']).ignore();
      }
    } catch (e) {
      if (mounted && widget.stories[_i] == s) {
        setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
      }
    }
  }

  Future<void> _loadViewers(String id) async {
    try {
      final v = await Api.I.storyViews(id);
      if (mounted && widget.stories[_i]['id'] == id) setState(() => _viewers = v);
    } catch (_) {}
  }

  void _next() {
    if (_i < widget.stories.length - 1) {
      _i++;
      _show();
    } else if (mounted) {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_i > 0) _i--;
    _show();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _sendReply() async {
    final t = _reply.text.trim();
    final c = _content;
    if (t.isEmpty || c == null) return;
    try {
      await sendStatusReply(widget.stories[_i], t, c.preview);
      _reply.clear();
      _focus.unfocus();
      if (mounted) _snack('اتبعت الرد');
    } catch (e) {
      if (mounted) _snack(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _delete() async {
    _c.stop();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('مسح الحالة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('مسح')),
        ],
      ),
    );
    if (ok != true) {
      if (_content != null) _c.forward();
      return;
    }
    try {
      await Api.I.deleteStory(widget.stories[_i]['id']);
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) _snack('تعذر مسح الحالة');
    }
  }

  void _showViewers() {
    _c.stop();
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: _viewers.isEmpty
            ? const Padding(padding: EdgeInsets.all(24), child: Text('لسه محدش شاف الحالة'))
            : ListView(shrinkWrap: true, children: [
                for (final v in _viewers)
                  ListTile(
                    leading: const Icon(Icons.visibility),
                    title: Text(((v['name'] as String?)?.isNotEmpty == true ? v['name'] : v['phone'])
                        .toString()),
                    subtitle: Text(timeAgo(v['viewed_at'].toString())),
                  ),
              ]),
      ),
    ).whenComplete(() {
      if (_content != null && mounted) _c.forward();
    });
  }

  Widget _body() {
    final c = _content;
    if (c == null) {
      return _error != null
          ? Padding(
              padding: const EdgeInsets.all(24),
              child: Text(_error!,
                  textAlign: TextAlign.center, style: const TextStyle(color: Colors.white)))
          : const Center(child: CircularProgressIndicator());
    }
    if (c.kind == 'text') {
      return Container(
        color: statusColors[c.bg % statusColors.length],
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Text(c.text, textAlign: TextAlign.center, style: statusFont(c.font)),
      );
    }
    return Center(child: Image.memory(c.bytes!, fit: BoxFit.contain));
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.stories[_i];
    final n = widget.stories.length;
    final c = _content;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          if (_focus.hasFocus) {
            _focus.unfocus();
            return;
          }
          final w = MediaQuery.of(context).size.width;
          d.globalPosition.dx < w / 3 ? _prev() : _next();
        },
        onLongPressStart: (_) => _c.stop(),
        onLongPressEnd: (_) {
          if (_content != null && !_focus.hasFocus) _c.forward();
        },
        child: Stack(children: [
          Positioned.fill(child: _body()),
          Positioned.fill(
            child: SafeArea(
              child: Stack(children: [
                Positioned(
                  top: 8, left: 8, right: 8,
                  child: Column(children: [
                    Row(
                      children: List.generate(
                        n,
                        (i) => Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: AnimatedBuilder(
                              animation: _c,
                              builder: (_, __) => LinearProgressIndicator(
                                value: i < _i ? 1 : (i == _i ? _c.value : 0),
                                minHeight: 3,
                                backgroundColor: Colors.white24,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Row(children: [
                      IconButton(
                          icon: const Icon(Icons.close, color: Colors.white),
                          onPressed: () => Navigator.pop(context)),
                      Text('${widget.authorName}  •  ${timeAgo(s['created_at'].toString())}',
                          style: const TextStyle(color: Colors.white)),
                    ]),
                  ]),
                ),
                // تعليق الصورة
                if (c != null && c.kind == 'image' && c.caption.isNotEmpty)
                  Positioned(
                    bottom: 72, left: 16, right: 16,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: Colors.black54, borderRadius: BorderRadius.circular(12)),
                      child: Text(c.caption,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 16)),
                    ),
                  ),
                if (widget.mine)
                  Positioned(
                    bottom: 12, left: 16, right: 16,
                    child: Row(children: [
                      TextButton.icon(
                        onPressed: _showViewers,
                        icon: const Icon(Icons.visibility, color: Colors.white),
                        label: Text('${_viewers.length}', style: const TextStyle(color: Colors.white)),
                      ),
                      const Spacer(),
                      IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.white),
                          onPressed: _delete),
                    ]),
                  )
                else
                  Positioned(
                    bottom: 8, left: 8, right: 8,
                    child: Row(children: [
                      Expanded(
                        child: TextField(
                          controller: _reply,
                          focusNode: _focus,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'رد على الحالة...',
                            hintStyle: const TextStyle(color: Colors.white70),
                            filled: true,
                            fillColor: Colors.black45,
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(24),
                                borderSide: BorderSide.none),
                          ),
                          onSubmitted: (_) => _sendReply(),
                        ),
                      ),
                      IconButton(
                          icon: const Icon(Icons.send, color: Colors.white), onPressed: _sendReply),
                    ]),
                  ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
