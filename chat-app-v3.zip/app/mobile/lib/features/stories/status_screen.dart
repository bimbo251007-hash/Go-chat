import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/api.dart';
import 'composers.dart';
import 'status_privacy_screen.dart';
import 'status_ring.dart';
import 'status_style.dart';
import 'story_viewer.dart';

/// تبويب "الحالة" زي واتساب: حالتي، التحديثات الأخيرة، والتحديثات اللي اتشافت
class StatusScreen extends StatefulWidget {
  final bool active;
  const StatusScreen({super.key, required this.active});
  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  late Future<List<dynamic>> _future = Api.I.storiesFeed();

  void _reload() => setState(() => _future = Api.I.storiesFeed());

  @override
  void didUpdateWidget(StatusScreen old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) _future = Api.I.storiesFeed(); // تحديث عند فتح التبويب
  }

  String _nameOf(Map<String, dynamic> s) {
    final n = (s['name'] as String?) ?? '';
    return n.isNotEmpty ? n : (s['phone'] ?? 'مستخدم').toString();
  }

  Future<void> _textStatus() async {
    final ok = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => const TextStatusComposer()));
    if (ok == true) _reload();
  }

  Future<void> _imageStatus() async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (c) => SafeArea(
        child: Wrap(children: [
          ListTile(
              leading: const Icon(Icons.photo),
              title: const Text('صورة من المعرض'),
              onTap: () => Navigator.pop(c, ImageSource.gallery)),
          ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('الكاميرا'),
              onTap: () => Navigator.pop(c, ImageSource.camera)),
        ]),
      ),
    );
    if (src == null) return;
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1920, imageQuality: 85);
    if (x == null || !mounted) return;
    final bytes = await x.readAsBytes();
    if (!mounted) return;
    if (bytes.length > 10 * 1024 * 1024) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('الحد الأقصى للصورة 10 ميجا')));
      return;
    }
    final ok = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => ImageStatusComposer(bytes: bytes)));
    if (ok == true) _reload();
  }

  Future<void> _open(List<Map<String, dynamic>> stories, String name, bool mine) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => StoryViewerScreen(stories: stories, authorName: name, mine: mine)),
    );
    _reload();
  }

  Widget _header(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
        child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
      );

  Widget _avatar(String name) =>
      CircleAvatar(child: Text(name.isEmpty ? '?' : name.characters.first.toUpperCase()));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الحالة'),
        actions: [
          IconButton(
            tooltip: 'خصوصية الحالة',
            icon: const Icon(Icons.lock_outline),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const StatusPrivacyScreen())),
          ),
        ],
      ),
      floatingActionButton: Column(mainAxisSize: MainAxisSize.min, children: [
        FloatingActionButton.small(
            heroTag: 'statusText', onPressed: _textStatus, child: const Icon(Icons.edit)),
        const SizedBox(height: 12),
        FloatingActionButton(
            heroTag: 'statusImage', onPressed: _imageStatus, child: const Icon(Icons.photo_camera)),
      ]),
      body: FutureBuilder<List<dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final feed = snap.data ?? const [];
          final me = Api.I.userId;
          final mine = <Map<String, dynamic>>[];
          final others = <String, List<Map<String, dynamic>>>{};
          for (final e in feed) {
            final s = Map<String, dynamic>.from(e);
            if (s['user_id'] == me) {
              mine.add(s);
            } else {
              others.putIfAbsent(s['user_id'], () => []).add(s);
            }
          }
          bool unseen(String id) => others[id]!.any((s) => s['viewed'] != true);
          // الأحدث فوق
          int latest(String a, String b) =>
              others[b]!.last['created_at'].toString().compareTo(others[a]!.last['created_at'].toString());
          final recent = others.keys.where(unseen).toList()..sort(latest);
          final viewed = others.keys.where((k) => !unseen(k)).toList()..sort(latest);

          Widget tile(String id) {
            final list = others[id]!;
            final name = _nameOf(list.first);
            return ListTile(
              leading: StatusRing(
                  seen: list.map((s) => s['viewed'] == true).toList(), child: _avatar(name)),
              title: Text(name),
              subtitle: Text(timeAgo(list.last['created_at'].toString())),
              onTap: () => _open(list, name, false),
            );
          }

          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(padding: const EdgeInsets.only(bottom: 140), children: [
              ListTile(
                leading: Stack(clipBehavior: Clip.none, children: [
                  mine.isEmpty
                      ? SizedBox(width: 56, height: 56, child: Padding(padding: const EdgeInsets.all(4), child: _avatar('أنا')))
                      : StatusRing(seen: mine.map((_) => false).toList(), child: _avatar('أنا')),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: CircleAvatar(
                        radius: 10,
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        child: const Icon(Icons.add, size: 14, color: Colors.white)),
                  ),
                ]),
                title: const Text('حالتي'),
                subtitle: Text(mine.isEmpty
                    ? 'اضغط لإضافة تحديث'
                    : timeAgo(mine.last['created_at'].toString())),
                onTap: mine.isEmpty ? _imageStatus : () => _open(mine, 'حالتي', true),
              ),
              if (recent.isNotEmpty) _header('التحديثات الأخيرة'),
              for (final id in recent) tile(id),
              if (viewed.isNotEmpty) _header('التحديثات اللي اتشافت'),
              for (final id in viewed) tile(id),
              if (feed.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Text('لسه مفيش تحديثات من جهات اتصالك',
                      textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                ),
            ]),
          );
        },
      ),
    );
  }
}
