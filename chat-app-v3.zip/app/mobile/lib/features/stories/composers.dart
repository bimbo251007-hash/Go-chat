import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'status_style.dart';
import 'story_actions.dart';

/// حالة نصية بخلفية ملونة وخط قابل للتغيير (زي واتساب)
class TextStatusComposer extends StatefulWidget {
  const TextStatusComposer({super.key});
  @override
  State<TextStatusComposer> createState() => _TextStatusComposerState();
}

class _TextStatusComposerState extends State<TextStatusComposer> {
  final _c = TextEditingController();
  int _bg = 0, _font = 0;
  bool _busy = false;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final t = _c.text.trim();
    if (t.isEmpty || _busy) return;
    setState(() => _busy = true);
    try {
      final n = await postStory(kind: 'text', meta: {'text': t, 'bg': _bg, 'font': _font});
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('الحالة اتنشرت لـ $n من جهات اتصالك')));
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: statusColors[_bg],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
              tooltip: 'الخط',
              icon: const Icon(Icons.text_fields),
              onPressed: () => setState(() => _font = (_font + 1) % 3)),
          IconButton(
              tooltip: 'لون الخلفية',
              icon: const Icon(Icons.palette_outlined),
              onPressed: () => setState(() => _bg = (_bg + 1) % statusColors.length)),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: TextField(
            controller: _c,
            autofocus: true,
            maxLines: null,
            maxLength: 700,
            textAlign: TextAlign.center,
            cursorColor: Colors.white,
            style: statusFont(_font),
            decoration: const InputDecoration(
              border: InputBorder.none,
              hintText: 'اكتب حالة',
              hintStyle: TextStyle(color: Colors.white54),
              counterText: '',
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _busy ? null : _send,
        child: _busy
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.send),
      ),
    );
  }
}

/// معاينة صورة + تعليق قبل النشر
class ImageStatusComposer extends StatefulWidget {
  final Uint8List bytes;
  const ImageStatusComposer({super.key, required this.bytes});
  @override
  State<ImageStatusComposer> createState() => _ImageStatusComposerState();
}

class _ImageStatusComposerState extends State<ImageStatusComposer> {
  final _caption = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _caption.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final n = await postStory(
          kind: 'image', bytes: widget.bytes, meta: {'caption': _caption.text.trim()});
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('الحالة اتنشرت لـ $n من جهات اتصالك')));
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
      body: Column(children: [
        Expanded(child: Center(child: Image.memory(widget.bytes, fit: BoxFit.contain))),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _caption,
                  maxLength: 200,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'أضف تعليق...',
                    hintStyle: const TextStyle(color: Colors.white54),
                    filled: true,
                    fillColor: Colors.white12,
                    counterText: '',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _busy ? null : _send,
                icon: _busy
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.send),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
