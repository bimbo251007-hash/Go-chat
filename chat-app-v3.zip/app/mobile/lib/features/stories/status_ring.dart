import 'dart:math' as math;
import 'package:flutter/material.dart';

/// حلقة مقسّمة بعدد التحديثات: الملون = لسه ماتشافش، الرمادي = اتشاف (زي واتساب)
class StatusRing extends StatelessWidget {
  final List<bool> seen;
  final double size;
  final Widget child;
  const StatusRing({super.key, required this.seen, required this.child, this.size = 56});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RingPainter(seen, Theme.of(context).colorScheme.primary),
        child: Padding(padding: const EdgeInsets.all(6), child: child),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final List<bool> seen;
  final Color color;
  _RingPainter(this.seen, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final n = seen.length;
    if (n == 0) return;
    final gap = n == 1 ? 0.0 : 0.14;
    final sweep = (2 * math.pi - n * gap) / n;
    final rect = (Offset.zero & size).deflate(2);
    for (var i = 0; i < n; i++) {
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..color = seen[i] ? Colors.grey.shade400 : color;
      canvas.drawArc(rect, -math.pi / 2 + gap / 2 + i * (sweep + gap), sweep, false, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => true;
}
