import 'package:flutter/material.dart';
import '../../core/api.dart';

class StatusPrivacyScreen extends StatefulWidget {
  const StatusPrivacyScreen({super.key});
  @override
  State<StatusPrivacyScreen> createState() => _StatusPrivacyScreenState();
}

class _StatusPrivacyScreenState extends State<StatusPrivacyScreen> {
  String _mode = 'contacts';
  final Set<String> _sel = {};
  List<dynamic> _contacts = [];
  bool _loading = true, _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Future.wait([Api.I.storyPrivacy(), Api.I.storyContacts()]);
      final p = r[0] as Map<String, dynamic>;
      _mode = p['mode'] as String;
      _sel
        ..clear()
        ..addAll((p['userIds'] as List).cast<String>());
      _contacts = r[1] as List<dynamic>;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await Api.I.setStoryPrivacy(_mode, _mode == 'contacts' ? [] : _sel.toList());
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
      setState(() => _saving = false);
    }
  }

  Widget _option(String value, String title) => ListTile(
        leading: Icon(_mode == value ? Icons.radio_button_checked : Icons.radio_button_unchecked,
            color: _mode == value ? Theme.of(context).colorScheme.primary : null),
        title: Text(title),
        onTap: () => setState(() => _mode = value),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('خصوصية الحالة')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('مين يقدر يشوف تحديثات حالتي؟',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              _option('contacts', 'جهات اتصالي'),
              _option('except', 'جهات اتصالي ماعدا...'),
              _option('only', 'شارك مع... بس'),
              if (_mode != 'contacts') ...[
                const Divider(),
                if (_contacts.isEmpty)
                  const Padding(padding: EdgeInsets.all(16), child: Text('مفيش جهات اتصال لسه')),
                for (final c in _contacts)
                  CheckboxListTile(
                    value: _sel.contains(c['id']),
                    onChanged: (v) => setState(() {
                      v == true ? _sel.add(c['id']) : _sel.remove(c['id']);
                    }),
                    title: Text(((c['name'] as String?)?.isNotEmpty == true ? c['name'] : c['phone'])
                        .toString()),
                  ),
              ],
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('التغييرات بتأثر على التحديثات الجديدة بس، مش اللي اتنشرت قبل كده.',
                    style: TextStyle(color: Colors.grey)),
              ),
            ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('حفظ'),
          ),
        ),
      ),
    );
  }
}
