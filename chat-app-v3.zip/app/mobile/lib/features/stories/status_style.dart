import 'package:flutter/material.dart';

const statusColors = [
  Color(0xFF6C47FF), Color(0xFF00897B), Color(0xFFD81B60),
  Color(0xFFF57C00), Color(0xFF1E88E5), Color(0xFF37474F),
];

TextStyle statusFont(int i, {double size = 28}) {
  switch (i % 3) {
    case 1:
      return TextStyle(fontSize: size, fontStyle: FontStyle.italic, color: Colors.white);
    case 2:
      return TextStyle(fontSize: size, fontFamily: 'monospace', color: Colors.white);
    default:
      return TextStyle(fontSize: size, fontWeight: FontWeight.w700, color: Colors.white);
  }
}

String timeAgo(String iso) {
  final t = DateTime.tryParse(iso)?.toLocal();
  if (t == null) return '';
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'دلوقتي';
  if (d.inMinutes < 60) return 'من ${d.inMinutes} دقيقة';
  return 'من ${d.inHours} ساعة';
}
