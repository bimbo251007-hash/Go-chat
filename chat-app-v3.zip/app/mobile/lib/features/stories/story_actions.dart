import 'dart:convert';
import 'dart:typed_data';
import '../../core/api.dart';
import '../../core/crypto.dart';
import '../../core/socket.dart';

class StoryContent {
  final String kind; // image | text
  final Uint8List? bytes;
  final String text, caption;
  final int bg, font;
  StoryContent({
    required this.kind,
    this.bytes,
    this.text = '',
    this.caption = '',
    this.bg = 0,
    this.font = 0,
  });

  /// المعاينة اللي بتظهر في الرد على الحالة
  String get preview {
    if (kind == 'text') return text.length > 80 ? '${text.substring(0, 80)}…' : text;
    return caption.isNotEmpty ? caption : '📷 صورة';
  }
}

/// نشر حالة (صورة أو نص). التشفير زي رسائل الشات، والجمهور حسب إعدادات الخصوصية.
/// بيرجع عدد اللي هيشوفوا الحالة.
Future<int> postStory({
  required String kind,
  Uint8List? bytes,
  Map<String, dynamic> meta = const {},
}) async {
  final aud = await Api.I.storyAudience();
  final recipients = <String, String>{Api.I.userId!: E2E.I.myPublicB64};
  for (final a in aud) {
    final id = a['id'] as String, key = a['publicKey'] as String;
    // لو مفتاح حد اتغير، منشاركش الحالة معاه لحد ما يتأكد منه في المحادثة
    if (await E2E.I.checkPeer(id, key) != KeyStatus.changed) recipients[id] = key;
  }
  final audience = recipients.keys.where((k) => k != Api.I.userId).toList();
  if (audience.isEmpty) {
    throw Exception('مفيش حد هيشوف الحالة. ابدأ محادثة مع حد أو راجع إعدادات الخصوصية.');
  }

  final m = Map<String, dynamic>.from(meta)..['kind'] = kind;
  String? mediaId;
  if (kind == 'image') {
    final enc = await E2E.I.encryptBlob(bytes!);
    m['key'] = enc.key;
    m['mime'] = 'image/jpeg';
    m['size'] = bytes.length;
    mediaId = await Api.I.uploadBlob(enc.blob);
  }
  final payload =
      await E2E.I.encrypt(plaintext: jsonEncode(m), recipients: recipients, convId: 'story');
  await Api.I.postStory(kind, mediaId, payload, audience);
  return audience.length;
}

final Map<String, String?> _pubCache = {};

Future<String?> _authorPub(String uid) async {
  if (uid == Api.I.userId) return E2E.I.myPublicB64;
  if (_pubCache.containsKey(uid)) return _pubCache[uid];
  String? pub;
  try {
    final k = await Api.I.getKey(uid);
    pub = (await E2E.I.checkPeer(uid, k)) == KeyStatus.changed ? null : k;
  } catch (_) {
    pub = null;
  }
  _pubCache[uid] = pub;
  return pub;
}

/// فك تشفير الحالة (وتحميل الصورة لو موجودة) مع التحقق من سلامتها
Future<StoryContent> openStory(Map<String, dynamic> s) async {
  final uid = s['user_id'] as String;
  final pub = await _authorPub(uid);
  if (pub == null) {
    throw Exception('مفتاح صاحب الحالة اتغير. افتح محادثته وتأكد من رقم الأمان.');
  }
  final text = await E2E.I.decrypt(
      payload: s['ciphertext'], convId: 'story', senderId: uid, senderPubB64: pub);
  if (text == null) throw Exception('تعذر فك تشفير الحالة');
  final meta = jsonDecode(text) as Map<String, dynamic>;
  final kind = (meta['kind'] ?? s['kind'] ?? 'image') as String;

  if (kind == 'text') {
    return StoryContent(
      kind: 'text',
      text: (meta['text'] ?? '').toString(),
      bg: (meta['bg'] ?? 0) as int,
      font: (meta['font'] ?? 0) as int,
    );
  }
  final mid = s['media_id'];
  if (mid == null) throw Exception('الحالة ناقصة');
  final blob = await Api.I.downloadBlob(mid as String);
  final clear = await E2E.I.decryptBlob(blob, meta['key'] as String);
  if (clear == null) throw Exception('الحالة تالفة أو اتعدّلت');
  return StoryContent(kind: 'image', bytes: clear, caption: (meta['caption'] ?? '').toString());
}

/// الرد على حالة: رسالة E2E عادية في المحادثة الفردية مع صاحب الحالة، فيها اقتباس
Future<void> sendStatusReply(Map<String, dynamic> story, String text, String preview) async {
  final uid = story['user_id'] as String;
  final pub = await _authorPub(uid);
  if (pub == null) throw Exception('مفتاح صاحب الحالة اتغير. تأكد منه في المحادثة الأول.');
  final convId = await Api.I.openDirect(uid);
  final payload = await E2E.I.encrypt(
    plaintext: jsonEncode({
      'text': text,
      'quote': {'kind': 'status', 'preview': preview},
    }),
    recipients: {Api.I.userId!: E2E.I.myPublicB64, uid: pub},
    convId: convId,
  );
  final ok = ChatSocket.I.send({
    'type': 'send',
    'conversationId': convId,
    'ciphertext': payload,
    'msgType': 'reply',
    'tempId': DateTime.now().microsecondsSinceEpoch.toString(),
  });
  if (!ok) throw Exception('مفيش اتصال دلوقتي، حاول تاني');
}
