import 'package:flutter/material.dart';
import '../../core/api.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _name = TextEditingController();
  final _about = TextEditingController();
  bool _hideLastSeen = false;
  String _phone = '';
  bool _loading = true, _saving = false;

  @override
  void initState() {
    super.initState();
    Api.I.me().then((m) {
      if (!mounted) return;
      setState(() {
        _name.text = (m['name'] ?? '').toString();
        _about.text = (m['about'] ?? '').toString();
        _hideLastSeen = m['hideLastSeen'] == true;
        _phone = (m['phone'] ?? '').toString();
        _loading = false;
      });
    }).catchError((_) {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _about.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) return;
    setState(() => _saving = true);
    try {
      await Api.I.updateMe(name: name, about: _about.text.trim(), hideLastSeen: _hideLastSeen);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ملفي الشخصي')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(_phone, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 16),
              TextField(
                  controller: _name,
                  maxLength: 50,
                  decoration: const InputDecoration(labelText: 'الاسم', border: OutlineInputBorder())),
              const SizedBox(height: 8),
              TextField(
                  controller: _about,
                  maxLength: 140,
                  decoration: const InputDecoration(labelText: 'النبذة', border: OutlineInputBorder())),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('إخفاء آخر ظهور'),
                subtitle: const Text('محدش هيشوف آخر مرة كنت فيها أونلاين'),
                value: _hideLastSeen,
                onChanged: (v) => setState(() => _hideLastSeen = v),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('حفظ'),
              ),
            ]),
    );
  }
}
