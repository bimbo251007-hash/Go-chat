import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'core/api.dart';
import 'core/config.dart';
import 'core/session.dart';
import 'features/auth/login_screen.dart';
import 'features/home/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kReleaseMode && (!apiBase.startsWith('https://') || !wsBase.startsWith('wss://'))) {
    throw StateError('نسخة الإنتاج لازم تستخدم https و wss');
  }
  await Api.I.load();
  if (Api.I.refreshToken != null && Api.I.userId != null) await startSession();
  runApp(const ChatApp());
}

class ChatApp extends StatelessWidget {
  const ChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'شات',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFF6C47FF), useMaterial3: true),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: Api.I.refreshToken == null ? const LoginScreen() : const HomeScreen(),
    );
  }
}
